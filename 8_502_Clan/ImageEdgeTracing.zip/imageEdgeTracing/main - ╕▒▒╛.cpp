#include "imageEdgeTracing.h"
#include <QtWidgets/QApplication>
#include <QImage>
#include <QPoint>
#include <QColor>
#include <QRgb>
#include <QDebug>
#include <tool.h>
#include <ctime> 
#include "segmentimage.h"  
#include "imgproc/imgproc.hpp"
#include "highgui/highgui.hpp"
#include "core/core.hpp"
#include <iostream>
#include <QDir>
#include <QQueue> 
#include <iostream>  
#include <string.h>  
#include <cxcore.h>  
#include <cv.h>  
#include <highgui.h>  
#include <fstream>

using namespace std;
using namespace cv;

Mat src; Mat src_gray;
int thresh = 100;
int max_thresh = 255;
RNG rng(12345);
/// Function header  
void thresh_callback(int, void*);


bool search(int x, int y, int **img);
bool searchTest(int x, int y, int **img);
void copyImage(int **copyImg, int **img);
void copyImage1(int **copyImg, int **img);
Vec3b RandomColor(int value);
Mat getHistImg(const MatND& hist);//����hist��ȡֱ��ͼ
Mat histGray(Mat image);//�ڰ�ͼ���ֱ��ͼ
Mat histColor(Mat image);//��ɫͼ���ֱ��ͼ
int getSecondCrest(QString s);//ֱ��ͼ�ĵڶ�������

//��ֵ��λ�ָ�
void MergeSeg(Mat& img, const Scalar& colorDiff = Scalar::all(1))
{
	CV_Assert(!img.empty());
	RNG rng = theRNG();
	// ��������ͼ��  
	Mat mask(img.rows + 2, img.cols + 2,
		CV_8UC1, Scalar::all(0));
	for (int y = 0; y < img.rows; y++)
	{
		for (int x = 0; x < img.cols; x++)
		{
			if (mask.at<uchar>(y + 1, x + 1) == 0)
			{
				// ��ɫ����  
				Scalar newVal(rng(256), rng(256), rng(256));
				// ����ϲ�  
				floodFill(img, mask, Point(x, y)
					, newVal, 0, colorDiff, colorDiff);
			}
		}
	}
}

//�ֲ���ֵ������
Mat image3;
Mat target3;
//ȫ����ֵ��ֵ��
void globalTwoValue(Mat src, int value)
{
	target3 = Mat::zeros(src.size(), src.type());

	for (int i = 0; i < src.rows; i++)
	{
		for (int j = 0; j < src.cols; j++)
		{

			break;
			if (value > (int)src.at<uchar>(i, j))
				target3.at<uchar>(i, j) = 0;
			else
				target3.at<uchar>(i, j) = 255;

		}
	}
}
//8*8�ֲ���ֵ��,��ֵ=�ֲ�ƽ���Ҷ�ֵ
void localTwoValue(Mat src)
{
	//1.�����һ���м���8��ʣ�¼�������
	int countRow = src.rows / 8;
	int rowLeft = src.rows % 8;

	//2.���һ���м���8��ʣ�¼�������
	int countCol = src.cols / 8;
	int colLeft = src.cols % 8;


	target3 = Mat::zeros(src.size(), src.type());

	for (int k = 0; k < countRow; k++)
	{
		for (int l = 0; l < countCol; l++)
		{
			int value = 0;
			for (int i = k * 8; i < (k + 1) * 8; i++)
			{
				for (int j = l * 8; j < (l + 1) * 8; j++)
				{
					value += (int)src.at<uchar>(i, j);
				}
			}
			value = value / 64;
			for (int i = k * 8; i < (k + 1) * 8; i++)
			{
				for (int j = l * 8; j < (l + 1) * 8; j++)
				{
					if ((int)src.at<uchar>(i, j) < value)
						target3.at<uchar>(i, j) = 0;
					else
						target3.at<uchar>(i, j) = 255;
				}
			}
		}
	}

	//�ײ�����8*8����
	if (rowLeft != 0)
	{
		for (int k = countRow; k < countRow + rowLeft; k++)
		{
			for (int l = 0; l < countCol; l++)
			{
				int value = 0;
				for (int i = countRow * 8; i < countRow * 8 + rowLeft; i++)
				{
					for (int j = l * 8; j < (l + 1) * 8; j++)
					{
						value += (int)src.at<uchar>(i, j);
					}
				}
				value = value / (8 * rowLeft);
				for (int i = countRow * 8; i < countRow * 8 + rowLeft; i++)
				{
					for (int j = l * 8; j < (l + 1) * 8; j++)
					{
						if ((int)src.at<uchar>(i, j) < value)
							target3.at<uchar>(i, j) = 0;
						else
							target3.at<uchar>(i, j) = 255;
					}
				}
			}
		}
	}
	//�Ҳ಻��8*8����
	if (colLeft != 0)
	{
		for (int k = 0; k < countRow; k++)
		{
			for (int l = countCol; l < countCol + colLeft; l++)
			{
				int value = 0;
				for (int i = k * 8; i < (k + 1) * 8; i++)
				{
					for (int j = countCol * 8; j < countCol * 8 + colLeft; j++)
					{
						value += (int)src.at<uchar>(i, j);
					}
				}
				value = value / (8 * colLeft);
				for (int i = k * 8; i < (k + 1) * 8; i++)
				{
					for (int j = countCol * 8; j < countCol * 8 + colLeft; j++)
					{
						if ((int)src.at<uchar>(i, j) < value)
							target3.at<uchar>(i, j) = 0;
						else
							target3.at<uchar>(i, j) = 255;
					}
				}
			}
		}
	}
	//���½� rowleft * colleft ����
	if (rowLeft != 0 && colLeft != 0)
	{
		int value = 0;
		for (int i = 8 * countRow; i < src.rows; i++)
		{
			for (int j = 8 * countCol; j < src.cols; j++)
			{
				value += (int)src.at<uchar>(i, j);
			}
		}
		value = value / (rowLeft * colLeft);
		for (int i = 8 * countRow; i < src.rows; i++)
		{
			for (int j = 8 * countCol; j < src.cols; j++)
			{
				if ((int)src.at<uchar>(i, j) < value)
					target3.at<uchar>(i, j) = 0;
				else
					target3.at<uchar>(i, j) = 255;
			}
		}
	}

}

//�ֲ���ֵ������
int max_thresh1 = 20;
int current_radius = 5;
Mat gray_src, LBP_image, ELBP_image;
void Demo_ELBP(int, void*);

//OSTU��ֵ�ָ��㷨
int OtsuAlgThreshold(const Mat image)
{
	if (image.channels() != 1)
	{
		cout << "Please input Gray-image!" << endl;
		return 0;
	}
	int T = 0; //Otsu�㷨��ֵ  
	double varValue = 0; //��䷽���м�ֵ����  
	double w0 = 0; //ǰ�����ص�����ռ����  
	double w1 = 0; //�������ص�����ռ����  
	double u0 = 0; //ǰ��ƽ���Ҷ�  
	double u1 = 0; //����ƽ���Ҷ�  
	double Histogram[256] = { 0 }; //�Ҷ�ֱ��ͼ���±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ�����ص�����  
	uchar *data = image.data;
	double totalNum = image.rows*image.cols; //��������  
											 //����Ҷ�ֱ��ͼ�ֲ���Histogram�����±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ���ص���  
	for (int i = 0; i < image.rows; i++)   //Ϊ������������û�а�rows��cols���������  
	{
		for (int j = 0; j < image.cols; j++)
		{
			Histogram[data[i*image.step + j]]++;
		}
	}
	for (int i = 0; i < 255; i++)
	{
		//ÿ�α���֮ǰ��ʼ��������  
		w1 = 0;       u1 = 0;       w0 = 0;       u0 = 0;
		//***********����������ֵ����**************************  
		for (int j = 0; j <= i; j++) //�������ָ�ֵ����  
		{
			w1 += Histogram[j];  //�����������ص�����  
			u1 += j*Histogram[j]; //�������������ܻҶȺ�  
		}
		if (w1 == 0) //�����������ص���Ϊ0ʱ�˳�  
		{
			break;
		}
		u1 = u1 / w1; //��������ƽ���Ҷ�  
		w1 = w1 / totalNum; // �����������ص�����ռ����  
							//***********����������ֵ����**************************  

							//***********ǰ��������ֵ����**************************  
		for (int k = i + 1; k < 255; k++)
		{
			w0 += Histogram[k];  //ǰ���������ص�����  
			u0 += k*Histogram[k]; //ǰ�����������ܻҶȺ�  
		}
		if (w0 == 0) //ǰ���������ص���Ϊ0ʱ�˳�  
		{
			break;
		}
		u0 = u0 / w0; //ǰ������ƽ���Ҷ�  
		w0 = w0 / totalNum; // ǰ���������ص�����ռ����  
							//***********ǰ��������ֵ����**************************  

							//***********��䷽�����******************************  
		double varValueI = w0*w1*(u1 - u0)*(u1 - u0); //��ǰ��䷽�����  
		if (varValue < varValueI)
		{
			varValue = varValueI;
			T = i;
		}
	}
	return T;
}

//ͼ���޸��㷨
#define WINDOW_NAME1 "��ԭʼͼ��"
#define WINDOW_NAME2 "���޲���"

Mat srcImage1, inpaintMask;
// ԭ���ĵ�����
Point previousPoint(-1, -1);

//��Ե�����㷨
QPoint searchFromTop(int **srcArray, QPoint srcPoint)
{
	int x = srcPoint.x();
	int y = srcPoint.y();
	if (srcArray[x + 1][y - 1] == 0)
	{
		return QPoint(x + 1, y - 1);
	}
	else if (srcArray[x + 1][y] == 0)
	{
		return QPoint(x + 1, y);
	}
	else if (srcArray[x + 1][y + 1] == 0)
	{
		return QPoint(x + 1, y + 1);
	}
	else if (srcArray[x][y + 1] == 0)
	{
		return QPoint(x, y + 1);
	}
	else if (y != 0 && srcArray[x + 1][y - 1] == 0)
	{
		return QPoint(x + 1, y - 1);
	}
	else if (y != 0 && srcArray[x][y - 1] == 0)
	{
		return QPoint(x, y - 1);
	}
	else if (y != 0 && x != 0 && srcArray[x - 1][y - 1] == 0)
	{
		return  QPoint(x - 1, y - 1);
	}
	else if (y != 0 && srcArray[x][y - 1] == 0)
	{
		return  QPoint(x, y - 1);
	}
	return QPoint(x, y);
};
static void On_Mouse(int event, int x, int y, int flags, void *)
{
	if (event == EVENT_LBUTTONUP || !(flags & EVENT_FLAG_LBUTTON))
		previousPoint = Point(-1, -1);
	else if (event == EVENT_LBUTTONDOWN)
		previousPoint = Point(x, y);
	else if (event == EVENT_MOUSEMOVE && (flags & EVENT_FLAG_LBUTTON))
	{
		Point pt(x, y);
		if (previousPoint.x < 0)
			previousPoint = pt;

		line(inpaintMask, previousPoint, pt, Scalar::all(255), 3, 8, 0);
		line(srcImage1, previousPoint, pt, Scalar::all(255), 3, 8, 0);
		previousPoint = pt;
		imshow(WINDOW_NAME1, srcImage1);
	}
}

// ������������


IplImage *image = 0; //ԭʼͼ��  
IplImage *image2 = 0; //ԭʼͼ��copy  

using namespace std;
int Thresholdness = 141;
int ialpha = 20;
int ibeta = 20;
int igamma = 20;

//void onChange(int pos)
//{
//
//	if (image2) cvReleaseImage(&image2);
//	if (image) cvReleaseImage(&image);
//
//	image2 = cvLoadImage("grey.bmp", 1); //��ʾͼƬ  
//	image = cvLoadImage("grey.bmp", 0);
//
//	cvThreshold(image, image, Thresholdness, 255, CV_THRESH_BINARY); //�ָ���ֵ     
//
//	CvMemStorage* storage = cvCreateMemStorage(0);
//	CvSeq* contours = 0;
//
//	cvFindContours(image, storage, &contours, sizeof(CvContour), //Ѱ�ҳ�ʼ������  
//		CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
//
//	if (!contours) return;
//	int length = contours->total;
//	if (length<10) return;
//	CvPoint* point = new CvPoint[length]; //����������  
//
//	CvSeqReader reader;
//	CvPoint pt = cvPoint(0, 0);;
//	CvSeq *contour2 = contours;
//
//	cvStartReadSeq(contour2, &reader);
//	for (int i = 0; i < length; i++)
//	{
//		CV_READ_SEQ_ELEM(pt, reader);
//		point[i] = pt;
//	}
//	cvReleaseMemStorage(&storage);
//
//	//��ʾ��������  
//	for (int i = 0; i<length; i++)
//	{
//		int j = (i + 1) % length;
//		cvLine(image2, point[i], point[j], CV_RGB(0, 0, 255), 1, 8, 0);
//	}
//
//	float alpha = ialpha / 100.0f;
//	float beta = ibeta / 100.0f;
//	float gamma = igamma / 100.0f;
//
//	CvSize size;
//	size.width = 3;
//	size.height = 3;
//	CvTermCriteria criteria;
//	criteria.type = CV_TERMCRIT_ITER;
//	criteria.max_iter = 1000;
//	criteria.epsilon = 0.1;
//	cvSnakeImage(image, point, length, &alpha, &beta, &gamma, CV_VALUE, size, criteria, 0);
//
//	//��ʾ����  
//	for (int i = 0; i<length; i++)
//	{
//		int j = (i + 1) % length;
//		cvLine(image2, point[i], point[j], CV_RGB(0, 255, 0), 1, 8, 0);
//	}
//	delete[]point;
//
//}

int main(int argc, char *argv[])
{
	Tool tool;
	QApplication a(argc, argv);

	///********************�����������Կ�ʼ***************************/
	//cvNamedWindow("win1", 0);
	//cvCreateTrackbar("Thd", "win1", &Thresholdness, 255, onChange);
	//cvCreateTrackbar("alpha", "win1", &ialpha, 100, onChange);
	//cvCreateTrackbar("beta", "win1", &ibeta, 100, onChange);
	//cvCreateTrackbar("gamma", "win1", &igamma, 100, onChange);
	//cvResizeWindow("win1", 300, 500);
	//onChange(0);

	//for (;;)
	//{
	//	if (cvWaitKey(40) == 27) break;
	//	cvShowImage("win1", image2);
	//}
	//waitKey();
	///********************�����������Խ���***************************/

	/////***********************************�޸�ͼ���㷨6(�ڶ����ύ���㷨���ֵڶ����޸İ�)��ʼ*******************************************/
	//QImage orgImg;//ԭͼ
	//int **orgImgArray;//����ԭͼ������
	//orgImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgArray[i] = new int[250];
	//}
	//QImage curveImg;//����ͼ
	//int **curveImgArray;//��������ͼ������
	//curveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	curveImgArray[i] = new int[250];
	//}
	//QImage wipeCurveImg;//ȥ����ͼ
	//int **wipeCurveImgArray;//����ȥ����ͼ������
	//wipeCurveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	wipeCurveImgArray[i] = new int[250];
	//}
	//int subSize = 25;//ÿһС��Ĵ�С
	//int **subImgArray;//����ָ��ÿһ��С��ͼ��
	//subImgArray = new int*[subSize];
	//for (int i = 0; i < subSize; i++)
	//{
	//	subImgArray[i] = new int[subSize];
	//}
	//int **CurveAreaArray;//���������ۼ�������
	//CurveAreaArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaArray[i] = new int[250];
	//}
	//int **CurveAreaDisposeArray;//�����ٴι��������ۼ�������
	//CurveAreaDisposeArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaDisposeArray[i] = new int[250];
	//}
	//int detectSize = 50;//ÿһ�ָ�С��Ĵ�С��ȥ���ʱ���ã�
	//int **detectImgArray;//����ָ��ÿһ��С��ͼ��
	//detectImgArray = new int*[detectSize];
	//for (int i = 0; i < detectSize; i++)
	//{
	//	detectImgArray[i] = new int[detectSize];
	//}

	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();//��ȡ�ļ��б�
	//double toneupPSNR = 0;
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfoOrg = list.at(i);
	//	QFileInfo fileInfoCurve = list.at(i + 1);
	//	QString orgImgName = fileInfoOrg.fileName();//ԭͼ�ļ���
	//	QString curveImgName = fileInfoCurve.fileName();//����ͼ�ļ���
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName);//����ͼͼ��
	//	orgImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + orgImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			curveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ͼתΪ�Ҷ�ͼ�����浽����
	//			orgImgArray[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;//ԭͼתΪ�Ҷ�ͼ�����浽����
	//		}
	//	}
	//	for (int i = 0; i < 250 / subSize; i++)
	//	{
	//		for (int j = 0; j < 250 / subSize; j++)
	//		{
	//			tool.ImageSeg(curveImgArray, subImgArray, i * subSize, j * subSize, subSize);//�ָ�ͼ��
	//			int  thresholdValue = 0;
	//			thresholdValue = tool.getThresholdValueWithOtsu(subImgArray, subSize, subSize);//OSTU�����ֵ
	//			for (int m = i * subSize; m < subSize + i * subSize; m++)
	//			{
	//				for (int n = j * subSize; n < subSize + j * subSize; n++)
	//				{
	//					if (curveImgArray[m][n] > thresholdValue)
	//					{
	//						CurveAreaArray[m][n] = 255;
	//					}
	//					else
	//					{
	//						CurveAreaArray[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}
	//	tool.expandImg(CurveAreaArray, 250, 250);
	//	tool.moveNoise(CurveAreaArray,250,250,50);
	//	//���˵������ʵ��ۼ�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (tool.getRadius(CurveAreaArray, 250, 250, i, j) > 50)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//			}
	//		}
	//	}

	//	//Ϊ�˺�OpenCV�Դ���ȥ�ۺ�������һ�£�����ɫ�Ե�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (CurveAreaDisposeArray[i][j] == 255)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				CurveAreaDisposeArray[i][j] = 0;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//		}
	//	}
	//	QImage wipeImg1 = tool.toImage(CurveAreaDisposeArray, 250, 250);
	//	wipeImg1.save("C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName);//����Mask��������ʱ�ļ���

	//																						  //�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//																						  //��ԭ��ʼ
	//	String srcImagePath = "C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName.toStdString();//��ȡԭ�ۼ�ͼ��
	//	Mat srcImage = imread(srcImagePath);
	//	String inpaintMaskPath = "C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName.toStdString();//��ȡMASkͼ��
	//	Mat inpaintMask = imread(inpaintMaskPath, CV_LOAD_IMAGE_GRAYSCALE);
	//	//Mat Kernel = getStructuringElement(MORPH_RECT, Size(1, 1));
	//	//dilate(inpaintMask, inpaintMask, Kernel);//����һ��
	//	Mat inpaintedImage;
	//	inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_TELEA);
	//	//inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_NS);//����ͼ���޸��ķ���
	//	imwrite("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp", inpaintedImage);//����ȥ����ɵ�ͼ��
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp");//��ȡȥ����ɵ�ͼ��
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			wipeCurveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ȥ����ɵ�ͼ��
	//		}
	//	}

	//	//��ֵ����ȼ��㣨1��ʾ����ͼ��ԭͼ��2��ʾȥ����ͼ��ԭͼ��
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (curveImgArray[i][j] - orgImgArray[i][j])*(curveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1 = 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (wipeCurveImgArray[i][j] - orgImgArray[i][j])*(wipeCurveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	qDebug() << PSNR2;
	//	toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + orgImgName);
	//	//wipeCurveImg = tool.toImage(wipeCurveImgArray, 250, 250);
	//	//wipeCurveImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + curveImgName);//����ȥ����ɵ�ͼ��
	//}
	//toneupPSNR = (toneupPSNR * 2) / list.size();
	//qDebug() << "toneupPSNR:" << toneupPSNR;
	/////**************************�޸�ͼ���㷨3�����޸Ľ���****************************************************************/

	///***********************************�޸�ͼ���㷨5��ʼ*******************************************/
	//QImage orgImg;//ԭͼ
	//int **orgImgArray;//����ԭͼ������
	//orgImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgArray[i] = new int[250];
	//}
	//QImage curveImg;//����ͼ
	//int **curveImgArray;//��������ͼ������
	//curveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	curveImgArray[i] = new int[250];
	//}
	//QImage wipeCurveImg;//ȥ����ͼ
	//int **wipeCurveImgArray;//����ȥ����ͼ������
	//wipeCurveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	wipeCurveImgArray[i] = new int[250];
	//}

	//QImage fuseImg;//�߽��ںϵ�ͼ��
	//int **fuseImgArray;//����߽��ںϵ�ͼ�������
	//fuseImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	fuseImgArray[i] = new int[250];
	//}

	//int subSize = 25;//ÿһС��Ĵ�С
	//int **subImgArray;//����ָ��ÿһ��С��ͼ��
	//subImgArray = new int*[subSize];
	//for (int i = 0; i < subSize; i++)
	//{
	//	subImgArray[i] = new int[subSize];
	//}
	//int **CurveAreaArray;//���������ۼ�������
	//CurveAreaArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaArray[i] = new int[250];
	//}
	//int **CurveAreaDisposeArray;//�����ٴι��������ۼ�������
	//CurveAreaDisposeArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaDisposeArray[i] = new int[250];
	//}

	//int resubSize = 50;//ÿһС��Ĵ�С
	//int **resubImgArray;//����ָ��ÿһ��С��ͼ��
	//resubImgArray = new int*[resubSize];
	//for (int i = 0; i < resubSize; i++)
	//{
	//	resubImgArray[i] = new int[resubSize];
	//}

	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();//��ȡ�ļ��б�
	//double toneupPSNR = 0;
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfoOrg = list.at(i);
	//	QFileInfo fileInfoCurve = list.at(i + 1);
	//	QString orgImgName = fileInfoOrg.fileName();//ԭͼ�ļ���
	//	QString curveImgName = fileInfoCurve.fileName();//����ͼ�ļ���
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName);//����ͼͼ��
	//	orgImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + orgImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			curveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ͼתΪ�Ҷ�ͼ�����浽����
	//			orgImgArray[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;//ԭͼתΪ�Ҷ�ͼ�����浽����
	//		}
	//	}
	//	for (int i = 0; i < 250 / subSize; i++)
	//	{
	//		for (int j = 0; j < 250 / subSize; j++)
	//		{
	//			tool.ImageSeg(curveImgArray, subImgArray, i * subSize, j * subSize, subSize);//�ָ�ͼ��
	//			int  thresholdValue = 0;
	//			thresholdValue = tool.getThresholdValueWithOtsu(subImgArray, subSize, subSize);//OSTU�����ֵ
	//			for (int m = i * subSize; m < subSize + i * subSize; m++)
	//			{
	//				for (int n = j * subSize; n < subSize + j * subSize; n++)
	//				{
	//					if (curveImgArray[m][n] > thresholdValue)
	//					{
	//						CurveAreaArray[m][n] = 255;
	//					}
	//					else
	//					{
	//						CurveAreaArray[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}


	//	tool.moveNoise(CurveAreaArray, 250, 250, 250);//�������
	//	//tool.expandImg(CurveAreaArray, 250, 250);
	//	//tool.expandImg(CurveAreaArray, 250, 250);
	//	//tool.expandImg(CurveAreaArray, 250, 250);
	//	//�߽��ںϲ�����ͼ�񣬶Ա߽��ںϵ�ͼ������һ����ֵ��
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (CurveAreaArray[i][j] == 0)
	//			{
	//				fuseImgArray[i][j] = curveImgArray[i][j];
	//			}
	//			else
	//			{
	//				fuseImgArray[i][j] = 255;
	//			}
	//		}
	//	}

	//	fuseImg = tool.toImage(fuseImgArray, 250, 250);
	//	fuseImg.save("C:/Users/Han/Desktop/Experiment/fuseImg.bmp");
	//	//for (int i = 0; i < 250 / resubSize; i++)
	//	//{
	//	//	for (int j = 0; j < 250 / resubSize; j++)
	//	//	{
	//	//		tool.ImageSeg(fuseImgArray, resubImgArray, i * resubSize, j * resubSize, resubSize);//�ָ�ͼ��
	//	//		int  thresholdValue = 0;
	//	//		int max = tool.getMaxExcept255(resubImgArray, resubSize, resubSize);
	//	//		/*for (int m = 0; m < resubSize; m++)
	//	//		{
	//	//			for (int n = 0; n < resubSize; n++)
	//	//			{
	//	//				if (resubImgArray[m][n] == 255)
	//	//				{
	//	//					resubImgArray[m][n] = max;
	//	//				}
	//	//			}
	//	//		}*/
	//	//		//thresholdValue = tool.getThresholdValueWithOtsu(resubImgArray, resubSize, resubSize);//OSTU�����ֵ
	//	//		//thresholdValue = tool.getThresholdValueWithOtsuParty(resubImgArray, resubSize, resubSize);//����OSTU�����ֵ
	//	//		//thresholdValue = tool.getThresholdValueWithVarimax(subImgArray, subSize, subSize);
	//	//		thresholdValue = tool.getThresholdValueWithFrequency(resubImgArray, resubSize, resubSize,0.25);
	//	//		for (int m = i * resubSize; m < resubSize + i * resubSize; m++)
	//	//		{
	//	//			for (int n = j * resubSize; n < resubSize + j * resubSize; n++)
	//	//			{
	//	//				if (resubImgArray[m - i * resubSize][n - j * resubSize] > thresholdValue)
	//	//				{
	//	//					CurveAreaArray[m][n] = 255;
	//	//				}
	//	//				else
	//	//				{
	//	//					CurveAreaArray[m][n] = 0;
	//	//				}
	//	//					//CurveAreaArray[m][n] = resubImgArray[m- i * resubSize][n- j * resubSize];
	//	//			}
	//	//		}
	//	//	}
	//	//}

	//	//tool.moveNoise(CurveAreaArray, 250, 250, 250);//�������
	//	//tool.expandImg(CurveAreaArray, 250, 250);
	//	fuseImg = tool.toImage(CurveAreaArray, 250, 250);
	//	fuseImg.save("C:/Users/Han/Desktop/Experiment/fuseImg.bmp");

	//	tool.moveNoise(CurveAreaArray, 250, 250, 50);//�������
	//	//tool.expandImg(CurveAreaArray, 250, 250);
	//	//���˵������ʵ��ۼ�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (tool.getRadius(CurveAreaArray, 250, 250, i, j) >100)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//			}
	//		}
	//	}
	//	tool.moveNoise(CurveAreaArray, 250, 250, 50);//�������

	//	//Ϊ�˺�OpenCV�Դ���ȥ�ۺ�������һ�£�����ɫ�Ե�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (CurveAreaDisposeArray[i][j] == 255)
	//			{
	//				CurveAreaDisposeArray[i][j] = 0;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//		}
	//	}

	//	QImage wipeImg1 = tool.toImage(CurveAreaDisposeArray, 250, 250);
	//	wipeImg1.save("C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName);//����Mask��������ʱ�ļ���

	//	//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//	//��ԭ��ʼ
	//	String srcImagePath = "C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName.toStdString();//��ȡԭ�ۼ�ͼ��
	//	Mat srcImage = imread(srcImagePath);
	//	String inpaintMaskPath = "C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName.toStdString();//��ȡMASkͼ��
	//	Mat inpaintMask = imread(inpaintMaskPath, CV_LOAD_IMAGE_GRAYSCALE);
	//	//Mat Kernel = getStructuringElement(MORPH_RECT, Size(2, 2));
	//	//dilate(inpaintMask, inpaintMask, Kernel);//����һ��
	//	Mat inpaintedImage;
	//	inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_TELEA);
	//	//inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_NS);//����ͼ���޸��ķ���
	//	imwrite("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp", inpaintedImage);//����ȥ����ɵ�ͼ��
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp");//��ȡȥ����ɵ�ͼ��
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			wipeCurveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ȥ����ɵ�ͼ��
	//		}
	//	}
	//	//imshow(WINDOW_NAME2, inpaintedImage);
	//	//for (int i = 0; i < 250; i++)
	//	//{
	//	//	for (int j = 0; j < 250; j++)
	//	//	{
	//	//		if (CurveAreaDisposeArray[i][j] == 0)
	//	//		{
	//	//			int areaSize = 25;
	//	//			bool isRepair = false;
	//	//			//wipeCurveImgArray[i][j] = orgImgArray[i][j];//��ԭ�ۼ���Χ
	//	//			//wipeCurveImgArray[i][j] = orgImgArray[i][j] * 2 / 3 - 6;//��ԭ�ۼ���Χ
	//	//			
	//	//		//	if (i <= 125 && j <= 125)//ȡ����
	//	//		//	{
	//	//		//		for (int m = i; m < i + areaSize; m++)
	//	//		//		{
	//	//		//			for (int n = j; n < j + areaSize; n++)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		//	else if (i <= 125 && j >= 125)//ȡ����
	//	//		//	{
	//	//		//		for (int m = i; m < i + areaSize; m++)
	//	//		//		{
	//	//		//			for (int n = j; n > j - areaSize; n--)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		//	else if (i >= 125 && j <= 125)//ȡ����
	//	//		//	{
	//	//		//		for (int m = i; m > i - areaSize; m--)
	//	//		//		{
	//	//		//			for (int n = j; n < j + areaSize; n++)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		//	else//ȡ���ºͱ߽�
	//	//		//	{
	//	//		//		for (int m = i; m > i - areaSize; m--)
	//	//		//		{
	//	//		//			for (int n = j; n > j - areaSize; n--)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		}
	//	//		else
	//	//		{
	//	//			wipeCurveImgArray[i][j] = curveImgArray[i][j];//����ԭ
	//	//		}
	//	//		}
	//	//	}


	//	//��ֵ����ȼ��㣨1��ʾ����ͼ��ԭͼ��2��ʾȥ����ͼ��ԭͼ��
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (curveImgArray[i][j] - orgImgArray[i][j])*(curveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1 = 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (wipeCurveImgArray[i][j] - orgImgArray[i][j])*(wipeCurveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	//qDebug() << PSNR2;
	//	toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + orgImgName);
	//	//wipeCurveImg = tool.toImage(wipeCurveImgArray, 250, 250);
	//	//wipeCurveImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + curveImgName);//����ȥ����ɵ�ͼ��
	//}
	//toneupPSNR = (toneupPSNR * 2) / list.size();
	//qDebug() << "toneupPSNR:" << toneupPSNR;
	///**************************�޸�ͼ���㷨5����****************************************************************/

	/**************************�޸�ͼ���㷨2���ڶ��θ���Ԥ����õĽ������ʼ1.42********************************************/
	//QImage orgImg;//ԭͼ
	//int **orgImgArray;//����ԭͼ������
	//orgImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgArray[i] = new int[250];
	//}
	//QImage curveImg;//����ͼ
	//int **curveImgArray;//��������ͼ������
	//curveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	curveImgArray[i] = new int[250];
	//}
	//QImage wipeCurveImg;//ȥ����ͼ
	//int **wipeCurveImgArray;//����ȥ����ͼ������
	//wipeCurveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	wipeCurveImgArray[i] = new int[250];
	//}
	//int subSize = 25;//ÿһС��Ĵ�С
	//int **subImgArray;//����ָ��ÿһ��С��ͼ��
	//subImgArray = new int*[subSize];
	//for (int i = 0; i < subSize; i++)
	//{
	//	subImgArray[i] = new int[subSize];
	//}
	//int **CurveAreaArray;//���������ۼ�������
	//CurveAreaArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaArray[i] = new int[250];
	//}
	//int **CurveAreaDisposeArray;//�����ٴι��������ۼ�������
	//CurveAreaDisposeArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaDisposeArray[i] = new int[250];
	//}

	//QImage fuseImg;//�߽��ںϵ�ͼ��
	//int **fuseImgArray;//����߽��ںϵ�ͼ�������
	//fuseImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	fuseImgArray[i] = new int[250];
	//}

	//int resubSize = 50;//ÿһС��Ĵ�С
	//int **resubImgArray;//����ָ��ÿһ��С��ͼ��
	//resubImgArray = new int*[resubSize];
	//for (int i = 0; i < resubSize; i++)
	//{
	//	resubImgArray[i] = new int[resubSize];
	//}

	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();//��ȡ�ļ��б�
	//double toneupPSNR = 0;
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfoOrg = list.at(i);
	//	QFileInfo fileInfoCurve = list.at(i + 1);
	//	QString orgImgName = fileInfoOrg.fileName();//ԭͼ�ļ���
	//	QString curveImgName = fileInfoCurve.fileName();//����ͼ�ļ���
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName);//����ͼͼ��
	//	orgImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + orgImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			curveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ͼתΪ�Ҷ�ͼ
	//			orgImgArray[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;//ԭͼתΪ�Ҷ�ͼ
	//		}
	//	}
	//	for (int i = 0; i < 250 / subSize; i++)
	//	{
	//		for (int j = 0; j < 250 / subSize; j++)
	//		{
	//			tool.ImageSeg(curveImgArray, subImgArray, i * subSize, j * subSize, subSize);//�ָ�ͼ��
	//			int  thresholdValue = 0;
	//			thresholdValue = tool.getThresholdValueWithOtsu(subImgArray, subSize, subSize);//OSTU�����ֵ
	//			for (int m = i * subSize; m < subSize + i * subSize; m++)
	//			{
	//				for (int n = j * subSize; n < subSize + j * subSize; n++)
	//				{
	//					if (curveImgArray[m][n] > thresholdValue)
	//					{
	//						CurveAreaArray[m][n] = 255;
	//					}
	//					else
	//					{
	//						CurveAreaArray[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}

	//	//tool.moveNoise(CurveAreaArray, 250, 250, 250);//�������


	//	//�߽��ںϲ�����ͼ�񣬶Ա߽��ںϵ�ͼ������һ����ֵ��
	//	//for (int i = 0; i < 250; i++)
	//	//{
	//	//	for (int j = 0; j < 250; j++)
	//	//	{
	//	//		if (CurveAreaArray[i][j] == 0)
	//	//		{
	//	//			fuseImgArray[i][j] = curveImgArray[i][j];
	//	//		}
	//	//		else
	//	//		{
	//	//			fuseImgArray[i][j] = 255;
	//	//		}
	//	//	}
	//	//}

	//	///*fuseImg = tool.toImage(fuseImgArray, 250, 250);
	//	//fuseImg.save("C:/Users/Han/Desktop/Experiment/fuseImg.bmp");*/
	//	//for (int i = 0; i < 250 / resubSize; i++)
	//	//{
	//	//	for (int j = 0; j < 250 / resubSize; j++)
	//	//	{
	//	//		tool.ImageSeg(fuseImgArray, resubImgArray, i * resubSize, j * resubSize, resubSize);//�ָ�ͼ��
	//	//		int  thresholdValue = 0;
	//	//		int max = tool.getMaxExcept255(resubImgArray, resubSize, resubSize);
	//	//		for (int m = 0; m < resubSize; m++)
	//	//		{
	//	//			for (int n = 0; n < resubSize; n++)
	//	//			{
	//	//				if (resubImgArray[m][n] == 255)
	//	//				{
	//	//					resubImgArray[m][n] = max;
	//	//				}
	//	//			}
	//	//		}
	//	//		thresholdValue = tool.getThresholdValueWithOtsu(resubImgArray, resubSize, resubSize);//OSTU�����ֵ
	//	//		//thresholdValue = tool.getThresholdValueWithVarimax(subImgArray, subSize, subSize);
	//	//		for (int m = i * resubSize; m < resubSize + i * resubSize; m++)
	//	//		{
	//	//			for (int n = j * resubSize; n < resubSize + j * resubSize; n++)
	//	//			{
	//	//				if (fuseImgArray[m][n] > thresholdValue)
	//	//				{
	//	//					CurveAreaArray[m][n] = 255;
	//	//				}
	//	//				else
	//	//				{
	//	//					CurveAreaArray[m][n] = 0;
	//	//				}
	//	//			}
	//	//		}
	//	//	}
	//	//}

	//	//tool.moveNoise(CurveAreaArray, 250, 250, 250);//�������
	//	tool.expandImg(CurveAreaArray, 250, 250);
	//	/*fuseImg = tool.toImage(CurveAreaArray, 250, 250);
	//	fuseImg.save("C:/Users/Han/Desktop/Experiment/fuseImg.bmp");*/


	//	//���˵������ʵ��ۼ�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (tool.getRadius(CurveAreaArray, 250, 250, i, j) > 100)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//			}
	//		}
	//	}
	//	/*QImage wipeImg = tool.toImage(CurveAreaArray, 250, 250);
	//	wipeImg.save("C:/Users/Han/Desktop/Experiment/result1515.jpg");*/
	//	//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//	//��ԭ��ʼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (CurveAreaDisposeArray[i][j] == 0)
	//			{
	//				wipeCurveImgArray[i][j] = orgImgArray[i][j];//��ԭ�ۼ���Χ
	//			}
	//			else
	//			{
	//				wipeCurveImgArray[i][j] = curveImgArray[i][j];//����ԭ
	//			}
	//		}
	//	}


	//	//��ֵ����ȼ��㣨1��ʾ����ͼ��ԭͼ��2��ʾȥ����ͼ��ԭͼ��
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (curveImgArray[i][j] - orgImgArray[i][j])*(curveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1 = 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (wipeCurveImgArray[i][j] - orgImgArray[i][j])*(wipeCurveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	qDebug() << PSNR2;
	//	toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + orgImgName);
	//	wipeCurveImg = tool.toImage(wipeCurveImgArray, 250, 250);
	//	wipeCurveImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + curveImgName);
	//}
	//toneupPSNR = (toneupPSNR * 2) / list.size();
	//qDebug() << "toneupPSNR:" << toneupPSNR;
	/**************************�޸�ͼ���㷨2����********************************************/

	/***********************************�޸�ͼ���㷨4��ʼ*******************************************/
	//QImage orgImg;//ԭͼ
	//int **orgImgArray;//����ԭͼ������
	//orgImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgArray[i] = new int[250];
	//}

	//QImage curveImg;//����ͼ
	//int **curveImgArray;//��������ͼ������
	//curveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	curveImgArray[i] = new int[250];
	//}

	//QImage wipeCurveImg;//ȥ����ͼ
	//int **wipeCurveImgArray;//����ȥ����ͼ������
	//wipeCurveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	wipeCurveImgArray[i] = new int[250];
	//}

	//QImage erodeImg;//��ʴ�����ͼ��
	//int **erodeImgArray;//���港ʴͼ�������
	//erodeImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	erodeImgArray[i] = new int[250];
	//}

	//int subSize = 25;//ÿһ�ָ�С��Ĵ�С
	//int **subImgArray;//����ָ��ÿһ��С��ͼ��
	//subImgArray = new int*[subSize];
	//for (int i = 0; i < subSize; i++)
	//{
	//	subImgArray[i] = new int[subSize];
	//}

	//int detectSize = 250;//ÿһ�ָ�С��Ĵ�С��ȥ���ʱ���ã�
	//int **detectImgArray;//����ָ��ÿһ��С��ͼ��
	//detectImgArray = new int*[detectSize];
	//for (int i = 0; i < detectSize; i++)
	//{
	//	detectImgArray[i] = new int[detectSize];
	//}

	//int traceSize = 50;//ÿһ�ָ�С��Ĵ�С��ȥ���ʱ���ã�
	//int **traceImgArray;//����ָ��ÿһ��С��ͼ��
	//traceImgArray = new int*[traceSize];
	//for (int i = 0; i < traceSize; i++)
	//{
	//	traceImgArray[i] = new int[traceSize];
	//}

	//int **CurveAreaArray;//���������ۼ�������
	//CurveAreaArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaArray[i] = new int[250];
	//}

	//int **CurveAreaDisposeArray;//�����ٴι��������ۼ�������
	//CurveAreaDisposeArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaDisposeArray[i] = new int[250];
	//}

	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();//��ȡ�ļ��б�
	//double toneupPSNR = 0;
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfoOrg = list.at(i);
	//	QFileInfo fileInfoCurve = list.at(i + 1);
	//	QString orgImgName = fileInfoOrg.fileName();//ԭͼ�ļ���
	//	QString curveImgName = fileInfoCurve.fileName();//����ͼ�ļ���
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName);//����ͼͼ��
	//	orgImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + orgImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			curveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ͼתΪ�Ҷ�ͼ�����浽����
	//			orgImgArray[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;//ԭͼתΪ�Ҷ�ͼ�����浽����
	//		}
	//	}

	//	for (int i = 0; i < 250 / subSize; i++)
	//	{
	//		for (int j = 0; j < 250 / subSize; j++)
	//		{
	//			tool.ImageSeg(curveImgArray, subImgArray, i * subSize, j * subSize, subSize);//�ָ�ͼ��
	//			int  thresholdValue = 0;
	//			thresholdValue = tool.getThresholdValueWithOtsu(subImgArray, subSize, subSize);//OSTU�����ֵ
	//			for (int m = i * subSize; m < subSize + i * subSize; m++)
	//			{
	//				for (int n = j * subSize; n < subSize + j * subSize; n++)
	//				{
	//					if (curveImgArray[m][n] > thresholdValue)
	//					{
	//						CurveAreaArray[m][n] = 255;
	//					}
	//					else
	//					{
	//						CurveAreaArray[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}

	//	//int detectSize = 50;
	//	//�ֱ��ÿһ��С����������Ⲣȥ��
	//	for (int i = 0; i < 250 / detectSize; i++)
	//	{
	//		for (int j = 0; j < 250 / detectSize; j++)
	//		{
	//			tool.ImageSeg(CurveAreaArray, detectImgArray, i * detectSize, j * detectSize, detectSize);//�ָ�ͼ��
	//			//���ϱ߽�Ϊ��ʼ�㿪ʼ���,����Ϊһ����������ɫ����Ϊ125
	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[0][k] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(0, k));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}

	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[k][detectSize - 1] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(k, detectSize - 1));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}

	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[detectSize - 1][k] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(detectSize - 1, k));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}
	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[k][0] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(k, 0));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}

	//			for (int m = i * detectSize; m < detectSize + i * detectSize; m++)
	//			{
	//				for (int n = j * detectSize; n < detectSize + j * detectSize; n++)
	//				{
	//					if (detectImgArray[m - i * detectSize][n - j * detectSize] == 125)
	//					{
	//						CurveAreaDisposeArray[m][n] = 0;
	//					}
	//					else
	//					{
	//						CurveAreaDisposeArray[m][n] = 255;
	//					}
	//				}
	//			}

	//		}
	//	}

	//	//��ÿ��С������ֱ��
	//	for (int i = 0; i < 250 / traceSize; i++)
	//	{
	//		for (int j = 0; j < 250 / traceSize; j++)
	//		{
	//			tool.ImageSeg(CurveAreaDisposeArray, traceImgArray, i * traceSize, j * traceSize, traceSize);//�ָ�ͼ��
	//			for (int k = 0; k < traceSize; k++)
	//			{
	//				if (traceImgArray[0][k] == 0)//���ܵ���ʼ��
	//				{
	//					if (searchFromTop(traceImgArray, QPoint(0, k)).x() != 0 && searchFromTop(traceImgArray, QPoint(0, k)).y() != k)
	//					{
	//						for (int z = 0; z < 20; z++)//����ǰһ��ȫ�������µ���ɫ
	//						{
	//							if (traceImgArray[0][k + z] == 255)
	//							{
	//								break;
	//							}
	//							else
	//							{
	//								traceImgArray[0][k + z] = 80;
	//							}
	//						}
	//						QPoint currentPoint = searchFromTop(traceImgArray, QPoint(0, k));//�������
	//						traceImgArray[currentPoint.x()][currentPoint.y()] = 80;
	//						for (int z = 0; z < 20; z++)//����ǰһ��ȫ�������µ���ɫ
	//						{
	//							if (traceImgArray[currentPoint.x()][currentPoint.y() + z + 1] == 255)
	//							{
	//								break;
	//							}
	//							else
	//							{
	//								traceImgArray[currentPoint.x()][currentPoint.y() + z + 1] = 80;
	//							}
	//						}
	//						QPoint oldPoint = QPoint(300, 300);//��㸳ֵһ����һ����
	//						while (tool.getRadius(traceImgArray, traceSize, traceSize, currentPoint.x(), currentPoint.y()) <20 && currentPoint.x() != 0
	//							&& currentPoint.x() != traceSize - 1 && currentPoint.y() != traceSize - 1 && currentPoint.y() != 0 && oldPoint.x() != currentPoint.x()
	//							&& oldPoint.y() != currentPoint.y())//�߽���٣�����������
	//						{
	//							oldPoint = currentPoint;
	//							currentPoint = searchFromTop(traceImgArray, currentPoint);
	//							traceImgArray[currentPoint.x()][currentPoint.y()] = 80;//80Ϊ��㸳ֵ
	//							for (int z = 0; z < 20; z++)//����ǰһ��ȫ�������µ���ɫ
	//							{
	//								if (traceImgArray[currentPoint.x()][currentPoint.y() + z + 1] == 255)
	//								{
	//									break;
	//								}
	//								else
	//								{
	//									traceImgArray[currentPoint.x()][currentPoint.y() + z + 1] = 80;
	//								}
	//							}
	//						}
	//						//traceImgArray[currentPoint.x()][currentPoint.y()] = 0;
	//					}


	//					for (int m = i * traceSize; m < traceSize + i * traceSize; m++)//�߽���ٽ���֮�󱣴�
	//					{
	//						for (int n = j * traceSize; n < traceSize + j * traceSize; n++)
	//						{
	//							if (traceImgArray[m - i * traceSize][n - j * traceSize] == 80)
	//							{
	//								CurveAreaDisposeArray[m][n] = 80;
	//							}
	//						}
	//					}


	//				}
	//			}
	//		}
	//	}
	//	QImage wipeImg1 = tool.toImage(CurveAreaDisposeArray, 250, 250);//����ȥ����ͼƬ���������
	//	wipeImg1.save("C:/Users/Han/Desktop/Experiment/4145545.jpg");

	//	//���˵������ʵ��ۼ�
	//	//QImage wipeImg1 = tool.toImage(CurveAreaArray, 250, 250);
	//	wipeImg1.save("C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName);//����Mask��������ʱ�ļ���
	//	String srcImagePath1 = "C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName.toStdString();
	//	Mat srcImage1 = imread(srcImagePath1);
	//	Mat srcImage2 = srcImage1;
	//	Mat Kernel = getStructuringElement(MORPH_RECT, Size(5, 5));
	//	dilate(srcImage1, srcImage1, Kernel);//����
	//	erode(srcImage2, srcImage2, Kernel);//��ʴ
	//	/*imshow("tupian", srcImage2);
	//	waitKey();*/
	//	imwrite("C:/Users/Han/Desktop/Experiment/erode.jpg", srcImage2);
	//	erodeImg = QImage("C:/Users/Han/Desktop/Experiment/erode.jpg");
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (erodeImg.pixelColor(j, i).blue() > 125)
	//			{
	//				erodeImgArray[i][j] = 255;//��������
	//			}
	//			else
	//			{
	//				erodeImgArray[i][j] = 0;//��Ҫ����������
	//			}
	//		}
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (erodeImgArray[i][j] == 0)//����
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//			}
	//		}
	//	}

	//	//for (int i = 0; i < 250; i++)
	//	//{
	//	//	for (int j = 0; j < 250; j++)
	//	//	{
	//	//		if (tool.getRadius(CurveAreaArray, 250, 250, i, j) > 4)//���ݰ뾶��ȥ��ͼ��
	//	//		{
	//	//			CurveAreaDisposeArray[i][j] = 255;
	//	//		}
	//	//		else
	//	//		{
	//	//			CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//	//		}
	//	//	}
	//	//}

	//	//Ϊ�˺�OpenCV�Դ���ȥ�ۺ�������һ�£�����ɫ�Ե�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (CurveAreaDisposeArray[i][j] == 255)
	//			{
	//				CurveAreaDisposeArray[i][j] = 0;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//		}
	//	}
	//	wipeImg1 = tool.toImage(CurveAreaDisposeArray, 250, 250);
	//	wipeImg1.save("C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName);//����Mask��������ʱ�ļ���




	//	//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//	//��ԭ��ʼ
	//	String srcImagePath = "C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName.toStdString();//��ȡԭ�ۼ�ͼ��
	//	Mat srcImage = imread(srcImagePath);
	//	String inpaintMaskPath = "C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName.toStdString();//��ȡMASkͼ��
	//	Mat inpaintMask = imread(inpaintMaskPath, CV_LOAD_IMAGE_GRAYSCALE);
	//	Kernel = getStructuringElement(MORPH_RECT, Size(2, 2));
	//	dilate(inpaintMask, inpaintMask, Kernel);//����һ��
	//	imwrite("C:/Users/Han/Desktop/Experiment/inpaintMask.bmp", inpaintMask);//����ȥ����ɵ�ͼ��
	//	Mat inpaintedImage;
	//	inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_TELEA);
	//	//inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_NS);//����ͼ���޸��ķ���
	//	imwrite("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp", inpaintedImage);//����ȥ����ɵ�ͼ��
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp");//��ȡȥ����ɵ�ͼ��
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			wipeCurveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ȥ����ɵ�ͼ��
	//		}
	//	}


	//	//��ֵ����ȼ��㣨1��ʾ����ͼ��ԭͼ��2��ʾȥ����ͼ��ԭͼ��
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (curveImgArray[i][j] - orgImgArray[i][j])*(curveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1 = 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (wipeCurveImgArray[i][j] - orgImgArray[i][j])*(wipeCurveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	//qDebug() << PSNR2;
	//	toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + orgImgName);
	//	//wipeCurveImg = tool.toImage(wipeCurveImgArray, 250, 250);
	//	//wipeCurveImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + curveImgName);//����ȥ����ɵ�ͼ��
	//}
	//toneupPSNR = (toneupPSNR * 2) / list.size();
	//qDebug() << "toneupPSNR:" << toneupPSNR;
	/**************************�޸�ͼ���㷨4����****************************************************************/

	/////***********************************�޸�ͼ���㷨3(�ڶ����ύ���㷨�����޸İ�)��ʼ*******************************************/
	//QImage orgImg;//ԭͼ
	//int **orgImgArray;//����ԭͼ������
	//orgImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgArray[i] = new int[250];
	//}
	//QImage curveImg;//����ͼ
	//int **curveImgArray;//��������ͼ������
	//curveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	curveImgArray[i] = new int[250];
	//}
	//QImage wipeCurveImg;//ȥ����ͼ
	//int **wipeCurveImgArray;//����ȥ����ͼ������
	//wipeCurveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	wipeCurveImgArray[i] = new int[250];
	//}
	//int subSize = 25;//ÿһС��Ĵ�С
	//int **subImgArray;//����ָ��ÿһ��С��ͼ��
	//subImgArray = new int*[subSize];
	//for (int i = 0; i < subSize; i++)
	//{
	//	subImgArray[i] = new int[subSize];
	//}
	//int **CurveAreaArray;//���������ۼ�������
	//CurveAreaArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaArray[i] = new int[250];
	//}
	//int **CurveAreaDisposeArray;//�����ٴι��������ۼ�������
	//CurveAreaDisposeArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaDisposeArray[i] = new int[250];
	//}
	//int detectSize = 50;//ÿһ�ָ�С��Ĵ�С��ȥ���ʱ���ã�
	//int **detectImgArray;//����ָ��ÿһ��С��ͼ��
	//detectImgArray = new int*[detectSize];
	//for (int i = 0; i < detectSize; i++)
	//{
	//	detectImgArray[i] = new int[detectSize];
	//}

	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();//��ȡ�ļ��б�
	//double toneupPSNR = 0;
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfoOrg = list.at(i);
	//	QFileInfo fileInfoCurve = list.at(i + 1);
	//	QString orgImgName = fileInfoOrg.fileName();//ԭͼ�ļ���
	//	QString curveImgName = fileInfoCurve.fileName();//����ͼ�ļ���
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName);//����ͼͼ��
	//	orgImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + orgImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			curveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ͼתΪ�Ҷ�ͼ�����浽����
	//			orgImgArray[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;//ԭͼתΪ�Ҷ�ͼ�����浽����
	//		}
	//	}
	//	for (int i = 0; i < 250 / subSize; i++)
	//	{
	//		for (int j = 0; j < 250 / subSize; j++)
	//		{
	//			tool.ImageSeg(curveImgArray, subImgArray, i * subSize, j * subSize, subSize);//�ָ�ͼ��
	//			int  thresholdValue = 0;
	//			thresholdValue = tool.getThresholdValueWithOtsu(subImgArray, subSize, subSize);//OSTU�����ֵ
	//			for (int m = i * subSize; m < subSize + i * subSize; m++)
	//			{
	//				for (int n = j * subSize; n < subSize + j * subSize; n++)
	//				{
	//					if (curveImgArray[m][n] > thresholdValue)
	//					{
	//						CurveAreaArray[m][n] = 255;
	//					}
	//					else
	//					{
	//						CurveAreaArray[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}
	//	tool.expandImg(CurveAreaArray, 250, 250);
	//	//���˵������ʵ��ۼ�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (tool.getRadius(CurveAreaArray, 250, 250, i, j) > 14)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//			}
	//		}
	//	}
	//	//int detectSize = 50;
	//	//�ֱ��ÿһ��С����������Ⲣȥ��
	//	for (int i = 0; i < 250 / detectSize; i++)
	//	{
	//		for (int j = 0; j < 250 / detectSize; j++)
	//		{
	//			tool.ImageSeg(CurveAreaDisposeArray, detectImgArray, i * detectSize, j * detectSize, detectSize);//�ָ�ͼ��


	//																									  //���ϱ߽�Ϊ��ʼ�㿪ʼ���,����Ϊһ����������ɫ����Ϊ125
	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[0][k] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(0, k));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}

	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[k][detectSize - 1] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(k, detectSize - 1));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}

	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[detectSize - 1][k] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(detectSize - 1, k));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}
	//			for (int k = 0; k < detectSize; k++)
	//			{
	//				if (detectImgArray[k][0] == 0)//���ܵ���ʼ��
	//				{
	//					QQueue<QPoint> pointQueue;
	//					pointQueue.enqueue(QPoint(k, 0));
	//					while (!(pointQueue.isEmpty()))
	//					{
	//						QPoint currentPoint = pointQueue.dequeue();
	//						int x = currentPoint.x();
	//						int y = currentPoint.y();
	//						detectImgArray[x][y] = 125;
	//						//��ÿ����������е����
	//						if (x == 0 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}

	//						}
	//						else if (x == 0 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1 && y == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//						}
	//						else if (y == 0)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}

	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//						}
	//						else if (x == detectSize - 1)
	//						{
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}

	//						}
	//						else if (y == detectSize - 1)
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//						}
	//						else
	//						{
	//							if (detectImgArray[x - 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y));
	//								detectImgArray[x - 1][y] = 125;
	//							}
	//							if (detectImgArray[x + 1][y] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y));
	//								detectImgArray[x + 1][y] = 125;
	//							}
	//							if (detectImgArray[x][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y - 1));
	//								detectImgArray[x][y - 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y - 1));
	//								detectImgArray[x + 1][y - 1] = 125;
	//							}

	//							if (detectImgArray[x - 1][y - 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y - 1));
	//								detectImgArray[x - 1][y - 1] = 125;
	//							}
	//							if (detectImgArray[x - 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x - 1, y + 1));
	//								detectImgArray[x - 1][y + 1] = 125;
	//							}
	//							if (detectImgArray[x][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x, y + 1));
	//								detectImgArray[x][y + 1] = 125;
	//							}
	//							if (detectImgArray[x + 1][y + 1] == 0)
	//							{
	//								pointQueue.enqueue(QPoint(x + 1, y + 1));
	//								detectImgArray[x + 1][y + 1] = 125;
	//							}
	//						}
	//					}
	//				}
	//			}

	//			for (int m = i * detectSize; m < detectSize + i * detectSize; m++)
	//			{
	//				for (int n = j * detectSize; n < detectSize + j * detectSize; n++)
	//				{
	//					if (detectImgArray[m - i * detectSize][n - j * detectSize] == 125)
	//					{
	//						CurveAreaDisposeArray[m][n] = 0;
	//					}
	//					else
	//					{
	//						CurveAreaDisposeArray[m][n] = 255;
	//					}
	//				}
	//			}

	//		}
	//	}

	//	////���˵������ʵ��ۼ�
	//	//for (int i = 0; i < 250; i++)
	//	//{
	//	//	for (int j = 0; j < 250; j++)
	//	//	{
	//	//		if (tool.getRadius(CurveAreaArray, 250, 250, i, j) >14)//���ݰ뾶��ȥ��ͼ��
	//	//		{
	//	//			CurveAreaDisposeArray[i][j] = 255;
	//	//		}
	//	//		else
	//	//		{
	//	//			CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//	//		}
	//	//	}
	//	//}
	//	//Ϊ�˺�OpenCV�Դ���ȥ�ۺ�������һ�£�����ɫ�Ե�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (CurveAreaDisposeArray[i][j] == 255)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				CurveAreaDisposeArray[i][j] = 0;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//		}
	//	}
	//	QImage wipeImg1 = tool.toImage(CurveAreaDisposeArray, 250, 250);
	//	wipeImg1.save("C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName);//����Mask��������ʱ�ļ���

	//	//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//	//��ԭ��ʼ
	//	String srcImagePath = "C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName.toStdString();//��ȡԭ�ۼ�ͼ��
	//	Mat srcImage = imread(srcImagePath);
	//	String inpaintMaskPath = "C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName.toStdString();//��ȡMASkͼ��
	//	Mat inpaintMask = imread(inpaintMaskPath, CV_LOAD_IMAGE_GRAYSCALE);
	//	Mat Kernel = getStructuringElement(MORPH_RECT, Size(1, 1));
	//	dilate(inpaintMask, inpaintMask, Kernel);//����һ��
	//	Mat inpaintedImage;
	//	inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_TELEA);
	//	//inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_NS);//����ͼ���޸��ķ���
	//	imwrite("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp", inpaintedImage);//����ȥ����ɵ�ͼ��
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp");//��ȡȥ����ɵ�ͼ��
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			wipeCurveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ȥ����ɵ�ͼ��
	//		}
	//	}
	//	//imshow(WINDOW_NAME2, inpaintedImage);
	//	//for (int i = 0; i < 250; i++)
	//	//{
	//	//	for (int j = 0; j < 250; j++)
	//	//	{
	//	//		if (CurveAreaDisposeArray[i][j] == 0)
	//	//		{
	//	//			int areaSize = 25;
	//	//			bool isRepair = false;
	//	//			//wipeCurveImgArray[i][j] = orgImgArray[i][j];//��ԭ�ۼ���Χ
	//	//			//wipeCurveImgArray[i][j] = orgImgArray[i][j] * 2 / 3 - 6;//��ԭ�ۼ���Χ
	//	//			
	//	//		//	if (i <= 125 && j <= 125)//ȡ����
	//	//		//	{
	//	//		//		for (int m = i; m < i + areaSize; m++)
	//	//		//		{
	//	//		//			for (int n = j; n < j + areaSize; n++)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		//	else if (i <= 125 && j >= 125)//ȡ����
	//	//		//	{
	//	//		//		for (int m = i; m < i + areaSize; m++)
	//	//		//		{
	//	//		//			for (int n = j; n > j - areaSize; n--)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		//	else if (i >= 125 && j <= 125)//ȡ����
	//	//		//	{
	//	//		//		for (int m = i; m > i - areaSize; m--)
	//	//		//		{
	//	//		//			for (int n = j; n < j + areaSize; n++)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		//	else//ȡ���ºͱ߽�
	//	//		//	{
	//	//		//		for (int m = i; m > i - areaSize; m--)
	//	//		//		{
	//	//		//			for (int n = j; n > j - areaSize; n--)
	//	//		//			{
	//	//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
	//	//		//				{
	//	//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
	//	//		//					isRepair == true;
	//	//		//				}
	//	//		//			}
	//	//		//		}
	//	//		//	}
	//	//		}
	//	//		else
	//	//		{
	//	//			wipeCurveImgArray[i][j] = curveImgArray[i][j];//����ԭ
	//	//		}
	//	//		}
	//	//	}


	//	//��ֵ����ȼ��㣨1��ʾ����ͼ��ԭͼ��2��ʾȥ����ͼ��ԭͼ��
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (curveImgArray[i][j] - orgImgArray[i][j])*(curveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1 = 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (wipeCurveImgArray[i][j] - orgImgArray[i][j])*(wipeCurveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	qDebug() << PSNR2;
	//	toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + orgImgName);
	//	//wipeCurveImg = tool.toImage(wipeCurveImgArray, 250, 250);
	//	//wipeCurveImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + curveImgName);//����ȥ����ɵ�ͼ��
	//}
	//toneupPSNR = (toneupPSNR * 2) / list.size();
	//qDebug() << "toneupPSNR:" << toneupPSNR;
	/////**************************�޸�ͼ���㷨3�����޸Ľ���****************************************************************/

	///***********************************��ʴ�������㷨���Կ�ʼ************************************************************/
	//Mat srcImage = imread("C:/Users/Han/Desktop/Experiment/resultData/0000484001/10000484001.jpg");
	//Mat srcImage1 = srcImage;
	//Mat Kernel = getStructuringElement(MORPH_RECT, Size(5, 5));
	//dilate(srcImage, srcImage, Kernel);//����
	//imshow("srcImage", srcImage);
	//imwrite("C:/Users/Han/Desktop/Experiment/dilate.jpg", srcImage);
	//erode(srcImage1, srcImage1, Kernel);//��ʴ
	//imshow("srcImage1", srcImage1);
	//imwrite("C:/Users/Han/Desktop/Experiment/erode.jpg", srcImage1);
	//waitKey();
	///***********************************��ʴ�������㷨���Խ���************************************************************/
	/***********************************��Ե����㷨���Կ�ʼ*******************************************************************/
	//Mat src, src_gray, dst;

	////src = imread("C:/Users/Han/Desktop/Experiment/result2.jpg");
	//src = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
	//if (src.empty())
	//	return -1;

	//namedWindow("Original", CV_WINDOW_AUTOSIZE);
	//namedWindow("Sobel", CV_WINDOW_AUTOSIZE);
	//namedWindow("Laplace", CV_WINDOW_AUTOSIZE);
	//namedWindow("Canny", CV_WINDOW_AUTOSIZE);

	//imshow("Original", src);

	//Mat grad_x, grad_y, abs_grad_x, abs_grad_y;

	//GaussianBlur(src, src, Size(3, 3), 0);
	//cvtColor(src, src_gray, COLOR_BGR2GRAY);

	//Sobel(src_gray, grad_x, CV_16S, 0, 1);        // use CV_16S to avoid overflow
	//convertScaleAbs(grad_x, abs_grad_x);
	//Sobel(src_gray, grad_y, CV_16S, 1, 0);        // use CV_16S to avoid overflow
	//convertScaleAbs(grad_y, abs_grad_y);
	//addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0, dst);
	//imshow("Sobel", dst);
	//imwrite("C:/Users/Han/Desktop/Experiment/Sobel.jpg", dst);

	//Laplacian(src_gray, dst, -1, 3);
	//imshow("Laplace", dst);
	//imwrite("C:/Users/Han/Desktop/Experiment/laplace.jpg", dst);

	//Canny(src_gray, dst, 100, 300);
	//imshow("Canny", dst);
	//imwrite("C:/Users/Han/Desktop/Experiment/Canny.jpg", dst);


	//waitKey(0);
	/***********************************��Ե����㷨���Խ���*******************************************************************/
	/***********************************OpenCVͼ���޸��㷨��ֱ�Ӷ�ȡͼ�񣩿�ʼ*************************************************************/
	//Mat imageSource = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
	//if (!imageSource.data)
	//{
	//	return -1;
	//}
	//imshow("ԭͼ", imageSource);
	//Mat imageGray;
	////ת��Ϊ�Ҷ�ͼ
	//cvtColor(imageSource, imageGray, CV_RGB2GRAY, 0);
	//Mat imageMask = Mat(imageSource.size(), CV_8UC1, Scalar::all(0));

	////ͨ����ֵ��������Mask
	//threshold(imageGray, imageMask, 240, 250, CV_THRESH_BINARY);
	//Mat Kernel = getStructuringElement(MORPH_RECT, Size(3, 3));
	////��Mask���ʹ���������Mask���
	//dilate(imageMask, imageMask, Kernel);

	////ͼ���޸�
	//inpaint(imageSource, imageMask, imageSource, 5, INPAINT_TELEA);
	//imshow("Mask", imageMask);
	//imshow("�޸���", imageSource);
	//waitKey();
	/***********************************OpenCVͼ���޸��㷨��ֱ�Ӷ�ȡͼ�񣩽���*************************************************************/
	/***********************************OpenCVͼ���޸��㷨��ʼ***************************************/
	//Mat srcImage = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg", -1);
	//if (!srcImage.data)
	//{
	//	printf("��ȡ��Ƭ����,��ȷ��Ŀ¼���Ƿ���imread����ָ����ͼƬ����!\n");
	//	return false;
	//}
	//srcImage1 = srcImage.clone();
	//inpaintMask = Mat::zeros(srcImage1.size(), CV_8U);

	//// ��ʾԭͼ
	//imshow(WINDOW_NAME1, srcImage1);

	//// ������Ϣ�ص���Ϣ
	//setMouseCallback(WINDOW_NAME1, On_Mouse, 0);

	//while (1)
	//{
	//	char c = (char)waitKey();

	//	// ����ΪESC���˳�
	//	if (c == 27)
	//		break;

	//	// ����Ϊ��2����ָ�ԭ��ͼ��
	//	if (c == '2')
	//	{
	//		inpaintMask = Scalar::all(0);
	//		srcImage.copyTo(srcImage1);
	//		imshow(WINDOW_NAME1, srcImage1);
	//	}

	//	// ����Ϊ1���߿ո�������޲�����
	//	if (c == '1' || c == ' ')
	//	{
	//		Mat inpaintedImage;
	//		inpaint(srcImage1, inpaintMask, inpaintedImage, 3, INPAINT_TELEA);
	//		imshow(WINDOW_NAME2, inpaintedImage);
	//	}

	//}
	//waitKey(0);
	/***********************************OpenCVͼ���޸��㷨����***************************************/
	/***********************************�޸�ͼ���㷨3(��һ���ύ���㷨)��ʼ*******************************************/
	QImage orgImg;//ԭͼ
	int **orgImgArray;//����ԭͼ������
	orgImgArray = new int*[250];
	for (int i = 0; i < 250; i++)
	{
		orgImgArray[i] = new int[250];
	}
	QImage curveImg;//����ͼ
	int **curveImgArray;//��������ͼ������
	curveImgArray = new int*[250];
	for (int i = 0; i < 250; i++)
	{
		curveImgArray[i] = new int[250];
	}
	QImage wipeCurveImg;//ȥ����ͼ
	int **wipeCurveImgArray;//����ȥ����ͼ������
	wipeCurveImgArray = new int*[250];
	for (int i = 0; i < 250; i++)
	{
		wipeCurveImgArray[i] = new int[250];
	}
	int subSize = 25;//ÿһС��Ĵ�С
	int **subImgArray;//����ָ��ÿһ��С��ͼ��
	subImgArray = new int*[subSize];
	for (int i = 0; i < subSize; i++)
	{
		subImgArray[i] = new int[subSize];
	}
	int **CurveAreaArray;//���������ۼ�������
	CurveAreaArray = new int*[250];
	for (int i = 0; i < 250; i++)
	{
		CurveAreaArray[i] = new int[250];
	}
	int **CurveAreaDisposeArray;//�����ٴι��������ۼ�������
	CurveAreaDisposeArray = new int*[250];
	for (int i = 0; i < 250; i++)
	{
		CurveAreaDisposeArray[i] = new int[250];
	}
	//��ȡͼ��
	QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	QFileInfoList list = dir.entryInfoList();//��ȡ�ļ��б�
	double toneupPSNR = 0;
	for (int i = 0; i < list.size(); i = i + 2)
	{
		QFileInfo fileInfoOrg = list.at(i);
		QFileInfo fileInfoCurve = list.at(i + 1);
		QString orgImgName = fileInfoOrg.fileName();//ԭͼ�ļ���
		QString curveImgName = fileInfoCurve.fileName();//����ͼ�ļ���
		curveImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName);//����ͼͼ��
		orgImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + orgImgName);//ԭͼ
		for (int i = 0; i < 250; i++)
		{
			for (int j = 0; j < 250; j++)
			{
				curveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
					curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ͼתΪ�Ҷ�ͼ�����浽����
				orgImgArray[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
					orgImg.pixelColor(j, i).green() * 59 + 50) / 100;//ԭͼתΪ�Ҷ�ͼ�����浽����
			}
		}
		for (int i = 0; i < 250 / subSize; i++)
		{
			for (int j = 0; j < 250 / subSize; j++)
			{
				tool.ImageSeg(curveImgArray, subImgArray, i * subSize, j * subSize, subSize);//�ָ�ͼ��
				int  thresholdValue = 0;
				thresholdValue = tool.getThresholdValueWithOtsu(subImgArray, subSize, subSize);//OSTU�����ֵ
				for (int m = i * subSize; m < subSize + i * subSize; m++)
				{
					for (int n = j * subSize; n < subSize + j * subSize; n++)
					{
						if (curveImgArray[m][n] > thresholdValue)
						{
							CurveAreaArray[m][n] = 255;
						}
						else
						{
							CurveAreaArray[m][n] = 0;
						}
					}
				}
			}
		}
		/*tool.expandImg(CurveAreaDisposeArray, 250, 250);*/
		//���˵������ʵ��ۼ�
		for (int i = 0; i < 250; i++)
		{
			for (int j = 0; j < 250; j++)
			{
				if (tool.getRadius(CurveAreaArray, 250, 250, i, j) > 10)//���ݰ뾶��ȥ��ͼ��
				{
					CurveAreaDisposeArray[i][j] = 255;
				}
				else
				{
					CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
				}
			}
		}
		
		//Ϊ�˺�OpenCV�Դ���ȥ�ۺ�������һ�£�����ɫ�Ե�
		for (int i = 0; i < 250; i++)
		{
			for (int j = 0; j < 250; j++)
			{
				if (CurveAreaDisposeArray[i][j] == 255)//���ݰ뾶��ȥ��ͼ��
				{
					CurveAreaDisposeArray[i][j] = 0;
				}
				else
				{
					CurveAreaDisposeArray[i][j] = 255;
				}
			}
		}
		QImage wipeImg1 = tool.toImage(CurveAreaDisposeArray, 250, 250);
		wipeImg1.save("C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName);//����Mask��������ʱ�ļ���

		//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
		//��ԭ��ʼ
		String srcImagePath = "C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName.toStdString();//��ȡԭ�ۼ�ͼ��
		Mat srcImage = imread(srcImagePath);
		String inpaintMaskPath = "C:/Users/Han/Desktop/Experiment/resultData/0000484001/1" + orgImgName.toStdString();//��ȡMASkͼ��
		Mat inpaintMask = imread(inpaintMaskPath, CV_LOAD_IMAGE_GRAYSCALE);
		//Mat Kernel = getStructuringElement(MORPH_RECT, Size(1,1));
		//dilate(inpaintMask, inpaintMask, Kernel);//����һ��
		Mat inpaintedImage;
		inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_TELEA);
		//inpaint(srcImage, inpaintMask, inpaintedImage, 3.0, INPAINT_NS);//����ͼ���޸��ķ���
		imwrite("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp", inpaintedImage);//����ȥ����ɵ�ͼ��
		curveImg = QImage("C:/Users/Han/Desktop/Experiment/resultData/0000484001/wipeImg1.bmp");//��ȡȥ����ɵ�ͼ��
		for (int i = 0; i < 250; i++)
		{
			for (int j = 0; j < 250; j++)
			{
				wipeCurveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
					curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ȥ����ɵ�ͼ��
			}
		}
		//imshow(WINDOW_NAME2, inpaintedImage);
		//for (int i = 0; i < 250; i++)
		//{
		//	for (int j = 0; j < 250; j++)
		//	{
		//		if (CurveAreaDisposeArray[i][j] == 0)
		//		{
		//			int areaSize = 25;
		//			bool isRepair = false;
		//			//wipeCurveImgArray[i][j] = orgImgArray[i][j];//��ԭ�ۼ���Χ
		//			//wipeCurveImgArray[i][j] = orgImgArray[i][j] * 2 / 3 - 6;//��ԭ�ۼ���Χ
		//			
		//		//	if (i <= 125 && j <= 125)//ȡ����
		//		//	{
		//		//		for (int m = i; m < i + areaSize; m++)
		//		//		{
		//		//			for (int n = j; n < j + areaSize; n++)
		//		//			{
		//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
		//		//				{
		//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
		//		//					isRepair == true;
		//		//				}
		//		//			}
		//		//		}
		//		//	}
		//		//	else if (i <= 125 && j >= 125)//ȡ����
		//		//	{
		//		//		for (int m = i; m < i + areaSize; m++)
		//		//		{
		//		//			for (int n = j; n > j - areaSize; n--)
		//		//			{
		//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
		//		//				{
		//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
		//		//					isRepair == true;
		//		//				}
		//		//			}
		//		//		}
		//		//	}
		//		//	else if (i >= 125 && j <= 125)//ȡ����
		//		//	{
		//		//		for (int m = i; m > i - areaSize; m--)
		//		//		{
		//		//			for (int n = j; n < j + areaSize; n++)
		//		//			{
		//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
		//		//				{
		//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
		//		//					isRepair == true;
		//		//				}
		//		//			}
		//		//		}
		//		//	}
		//		//	else//ȡ���ºͱ߽�
		//		//	{
		//		//		for (int m = i; m > i - areaSize; m--)
		//		//		{
		//		//			for (int n = j; n > j - areaSize; n--)
		//		//			{
		//		//				if (CurveAreaDisposeArray[m][n] != 0 && isRepair == false)
		//		//				{
		//		//					wipeCurveImgArray[i][j] = curveImgArray[m][n];
		//		//					isRepair == true;
		//		//				}
		//		//			}
		//		//		}
		//		//	}
		//		}
		//		else
		//		{
		//			wipeCurveImgArray[i][j] = curveImgArray[i][j];//����ԭ
		//		}
		//		}
		//	}


		//��ֵ����ȼ��㣨1��ʾ����ͼ��ԭͼ��2��ʾȥ����ͼ��ԭͼ��
		double MSE1 = 0;
		double MSE2 = 0;
		double PSNR1 = 0;
		double PSNR2 = 0;
		for (int i = 0; i < 250; i++)
		{
			for (int j = 0; j < 250; j++)
			{
				MSE1 += (curveImgArray[i][j] - orgImgArray[i][j])*(curveImgArray[i][j] - orgImgArray[i][j]);
			}
		}
		MSE1 = MSE1 / (250 * 250);
		PSNR1 = 10.0*log10((255 * 255) / MSE1);
		//qDebug()  << PSNR1;
		for (int i = 0; i < 250; i++)
		{
			for (int j = 0; j < 250; j++)
			{
				MSE2 += (wipeCurveImgArray[i][j] - orgImgArray[i][j])*(wipeCurveImgArray[i][j] - orgImgArray[i][j]);
			}
		}
		MSE2 = MSE2 / (250 * 250);
		PSNR2 = 10.0*log10((255 * 255) / MSE2);
		//qDebug() << PSNR2;
		toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
		orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + orgImgName);
		//wipeCurveImg = tool.toImage(wipeCurveImgArray, 250, 250);
		//wipeCurveImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + curveImgName);//����ȥ����ɵ�ͼ��
	}
	toneupPSNR = (toneupPSNR * 2) / list.size();
	qDebug() << "toneupPSNR:" << toneupPSNR;
	/**************************�޸�ͼ���㷨3����****************************************************************/
	/**************************�޸�ͼ���㷨2��Ԥ����õĽ������ʼ********************************************/
	//QImage orgImg;//ԭͼ
	//int **orgImgArray;//����ԭͼ������
	//orgImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgArray[i] = new int[250];
	//}
	//QImage curveImg;//����ͼ
	//int **curveImgArray;//��������ͼ������
	//curveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	curveImgArray[i] = new int[250];
	//}
	//QImage wipeCurveImg;//ȥ����ͼ
	//int **wipeCurveImgArray;//����ȥ����ͼ������
	//wipeCurveImgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	wipeCurveImgArray[i] = new int[250];
	//}
	//int subSize = 25;//ÿһС��Ĵ�С
	//int **subImgArray;//����ָ��ÿһ��С��ͼ��
	//subImgArray = new int*[subSize];
	//for (int i = 0; i < subSize; i++)
	//{
	//	subImgArray[i] = new int[subSize];
	//}
	//int **CurveAreaArray;//���������ۼ�������
	//CurveAreaArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaArray[i] = new int[250];
	//}
	//int **CurveAreaDisposeArray;//�����ٴι��������ۼ�������
	//CurveAreaDisposeArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	CurveAreaDisposeArray[i] = new int[250];
	//}
	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();//��ȡ�ļ��б�
	//double toneupPSNR = 0;
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfoOrg = list.at(i);
	//	QFileInfo fileInfoCurve = list.at(i + 1);
	//	QString orgImgName = fileInfoOrg.fileName();//ԭͼ�ļ���
	//	QString curveImgName = fileInfoCurve.fileName();//����ͼ�ļ���
	//	curveImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + curveImgName);//����ͼͼ��
	//	orgImg = QImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + orgImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			curveImgArray[i][j] = (curveImg.pixelColor(j, i).blue() * 11 + curveImg.pixelColor(j, i).red() * 30 +
	//				curveImg.pixelColor(j, i).green() * 59 + 50) / 100;//����ͼתΪ�Ҷ�ͼ
	//			orgImgArray[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;//ԭͼתΪ�Ҷ�ͼ
	//		}
	//	}
	//	for (int i = 0; i < 250 / subSize; i++)
	//	{
	//		for (int j = 0; j < 250 / subSize; j++)
	//		{
	//			tool.ImageSeg(curveImgArray, subImgArray, i * subSize, j * subSize, subSize);//�ָ�ͼ��
	//			int  thresholdValue = 0;
	//			thresholdValue = tool.getThresholdValueWithOtsu(subImgArray, subSize, subSize);//OSTU�����ֵ
	//			for (int m = i * subSize; m < subSize + i * subSize; m++)
	//			{
	//				for (int n = j * subSize; n < subSize + j * subSize; n++)
	//				{
	//					if (curveImgArray[m][n] > thresholdValue)
	//					{
	//						CurveAreaArray[m][n] = 255;
	//					}
	//					else
	//					{
	//						CurveAreaArray[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}
	//	//���˵������ʵ��ۼ�
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (tool.getRadius(CurveAreaArray, 250, 250, i, j) > 50)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				CurveAreaDisposeArray[i][j] = 255;
	//			}
	//			else
	//			{
	//				CurveAreaDisposeArray[i][j] = CurveAreaArray[i][j];
	//			}
	//		}
	//	}
	//	/*QImage wipeImg = tool.toImage(CurveAreaArray, 250, 250);
	//	wipeImg.save("C:/Users/Han/Desktop/Experiment/result1515.jpg");*/
	//	//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//	//��ԭ��ʼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (CurveAreaDisposeArray[i][j] == 0)
	//			{
	//				wipeCurveImgArray[i][j] = orgImgArray[i][j];//��ԭ�ۼ���Χ
	//			}
	//			else
	//			{
	//				wipeCurveImgArray[i][j] = curveImgArray[i][j];//����ԭ
	//			}
	//		}
	//	}


	//	//��ֵ����ȼ��㣨1��ʾ����ͼ��ԭͼ��2��ʾȥ����ͼ��ԭͼ��
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (curveImgArray[i][j] - orgImgArray[i][j])*(curveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1 = 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (wipeCurveImgArray[i][j] - orgImgArray[i][j])*(wipeCurveImgArray[i][j] - orgImgArray[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	qDebug() << PSNR2;
	//	toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + orgImgName);
	//	wipeCurveImg = tool.toImage(wipeCurveImgArray, 250, 250);
	//	wipeCurveImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + curveImgName);
	//}
	//toneupPSNR = (toneupPSNR * 2) / list.size();
	//qDebug() << "toneupPSNR:" << toneupPSNR;
	/**************************�޸�ͼ���㷨2����********************************************/
	/*************************�޸�ͼ���㷨����1��ʼ*******************************/
	////����һ���ָ�ͼ��Ϊ50*50�Ŀ��С
	//int **orgImgA;//ԭͼ
	//orgImgA = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgA[i] = new int[250];
	//}
	//int **cohImgA;//��������ͼ��
	//cohImgA = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	cohImgA[i] = new int[250];
	//}
	//int **cohImgB;//����ǰͼ��
	//cohImgB = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	cohImgB[i] = new int[250];
	//}
	//int **imgArray;//���������
	//imgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgArray[i] = new int[250];
	//}
	//int **imgMidArray;//����ָ�ͼ�������м����
	//imgMidArray = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray[i] = new int[50];
	//}
	//int **imgMidArray1;//������ɫ�ۺ������м����
	//imgMidArray1 = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray1[i] = new int[50];
	//}
	//int **imgResult;//������
	//imgResult = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgResult[i] = new int[250];
	//}
	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();
	//double toneupPSNR = 0;
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfo1 = list.at(i);
	//	QFileInfo fileInfo2 = list.at(i + 1);
	//	QString originalImgName = fileInfo1.fileName();//ԭͼ
	//	QString pendImageName = fileInfo2.fileName();//������ͼ��
	//	//ȥ�ۿ�ʼ
	//	QImage cohImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + pendImageName);//��ȥ��ͼ��
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			imgArray[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			cohImgB[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	int size = 25;//ÿһ��Ĵ�С
	//	for (int i = 0; i < 250 / size; i++)
	//	{
	//		for (int j = 0; j < 250 / size; j++)
	//		{
	//			tool.ImageSeg(imgArray, imgMidArray, i * size, j * size, size);
	//			int  thresholdValue = 0;
	//			for (int m = 0; m < 25; m++)
	//			{
	//				for (int n = 0; n < 25; n++)
	//				{
	//					imgMidArray1[m][n] = imgMidArray[m][n] / 20 * 20;
	//				}
	//			}
	//			//thresholdValue = tool.getThresholdValue(imgMidArray1, 50, 50);//��ȡÿһ�������ֵ
	//			//thresholdValue = tool.getThresholdValueWithVarimax(imgMidArray, size, size);//��󷽲�����ֵ
	//			//thresholdValue = tool.getThresholdValueWithIteration(imgMidArray, size, size);//�����������ֵ
	//			thresholdValue = tool.getThresholdValueWithOtsu(imgMidArray, size, size);//OSTU�����ֵ
	//			for (int m = i * size; m < size + i * size; m++)
	//			{
	//				for (int n = j * size; n < size + j * size; n++)
	//				{
	//					if (imgArray[m][n] > thresholdValue)
	//					{
	//						imgResult[m][n] = 255;
	//					}
	//					else
	//					{
	//						imgResult[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}
	//	int **imgArrayR;//�����ۼ���Χ
	//	imgArrayR = new int*[250];
	//	for (int i = 0; i < 250; i++)
	//	{
	//		imgArrayR[i] = new int[250];
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (tool.getRadius(imgResult, 250, 250, i, j) > 50)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				imgArrayR[i][j] = 255;
	//			}
	//			else
	//			{
	//				imgArrayR[i][j] = imgResult[i][j];
	//			}
	//		}
	//	}
	//	//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//	//��ԭ��ʼ
	//	QImage orgImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + originalImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			imgArray[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}

	//	/*for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (imgArrayR[j][i] == 255)
	//			{

	//				cohImg.setPixelColor(j,i,orgImg.pixelColor(j,i));
	//			}
	//		}
	//	}*/


	//	//��ֵ����ȼ���
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			orgImgA[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (imgArrayR[j][i] == 255)
	//			{
	//				cohImgA[i][j] = orgImgA[i][j];
	//			}
	//			else
	//			{
	//				cohImgA[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//					orgImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//			}
	//		}
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			cohImgA[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (cohImgB[i][j] - orgImgA[i][j])*(cohImgB[i][j] - orgImgA[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1 = 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (cohImgA[i][j] - orgImgA[i][j])*(cohImgA[i][j] - orgImgA[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	//qDebug() << PSNR2;
	//	toneupPSNR += (PSNR2 - PSNR1) / PSNR1;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + originalImgName);
	//	cohImg = tool.toImage(cohImgA, 250, 250);
	//	cohImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + pendImageName);
	//}
	//toneupPSNR = (toneupPSNR * 2) / list.size();
	//qDebug() << "toneupPSNR:" << toneupPSNR;
	/*************************�޸�ͼ���㷨����1����*******************************/
	/*************************�޸�ͼ���㷨���Կ�ʼ*******************************/
	////����һ���ָ�ͼ��Ϊ50*50�Ŀ��С
	//int **orgImgA;//ԭͼ
	//orgImgA = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	orgImgA[i] = new int[250];
	//}
	//int **cohImgA;//��������ͼ��
	//cohImgA = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	cohImgA[i] = new int[250];
	//}
	//int **cohImgB;//����ǰͼ��
	//cohImgB= new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	cohImgB[i] = new int[250];
	//}
	//int **imgArray;//���������
	//imgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgArray[i] = new int[250];
	//}
	//int **imgMidArray;//����ָ�ͼ�������м����
	//imgMidArray = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray[i] = new int[50];
	//}
	//int **imgMidArray1;//������ɫ�ۺ������м����
	//imgMidArray1 = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray1[i] = new int[50];
	//}
	//int **imgResult;//������
	//imgResult = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgResult[i] = new int[250];
	//}
	////��ȡͼ��
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");//����Ŀ¼
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	//QFileInfoList list = dir.entryInfoList();
	//for (int i = 0; i < list.size(); i = i + 2)
	//{
	//	QFileInfo fileInfo1 = list.at(i);
	//	QFileInfo fileInfo2 = list.at(i + 1);
	//	QString originalImgName = fileInfo1.fileName();//ԭͼ
	//	QString pendImageName = fileInfo2.fileName();//������ͼ��
	//	//ȥ�ۿ�ʼ
	//	QImage cohImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/"+ pendImageName);//��ȥ��ͼ��
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			imgArray[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			cohImgB[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	int size = 25;//ÿһ��Ĵ�С
	//	for (int i = 0; i < 250 / size; i++)
	//	{
	//		for (int j = 0; j < 250 / size; j++)
	//		{
	//			tool.ImageSeg(imgArray, imgMidArray, i * size, j * size, size);
	//			int  thresholdValue = 0;
	//			for (int m = 0; m < 25; m++)
	//			{
	//				for (int n = 0; n < 25; n++)
	//				{
	//					imgMidArray1[m][n] = imgMidArray[m][n] / 20 * 20;
	//				}
	//			}
	//			//thresholdValue = tool.getThresholdValue(imgMidArray1, 50, 50);//��ȡÿһ�������ֵ
	//			//thresholdValue = tool.getThresholdValueWithVarimax(imgMidArray, size, size);//��󷽲�����ֵ
	//			//thresholdValue = tool.getThresholdValueWithIteration(imgMidArray, size, size);//�����������ֵ
	//			thresholdValue = tool.getThresholdValueWithOtsu(imgMidArray, size, size);//OSTU�����ֵ
	//			for (int m = i * size; m < size + i * size; m++)
	//			{
	//				for (int n = j * size; n < size + j * size; n++)
	//				{
	//					if (imgArray[m][n] > thresholdValue)
	//					{
	//						imgResult[m][n] = 255;
	//					}
	//					else
	//					{
	//						imgResult[m][n] = 0;
	//					}
	//				}
	//			}
	//		}
	//	}
	//	int **imgArrayR;//�����ۼ���Χ
	//	imgArrayR = new int*[250];
	//	for (int i = 0; i < 250; i++)
	//	{
	//		imgArrayR[i] = new int[250];
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (tool.getRadius(imgResult, 250, 250, i, j) > 15)//���ݰ뾶��ȥ��ͼ��
	//			{
	//				imgArrayR[i][j] = 255;
	//			}
	//			else
	//			{
	//				imgArrayR[i][j] = imgResult[i][j];
	//			}
	//		}
	//	}
	//	//�Դ����ҵ��ۼ���Χ����ʼͼ��ԭ
	//	//��ԭ��ʼ
	//	QImage orgImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/" + originalImgName);//ԭͼ
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			imgArray[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			if (imgArrayR[j][i] == 255)
	//			{
	//				cohImg.setPixelColor(j,i,orgImg.pixelColor(j,i));
	//			}
	//		}
	//	}

	//	//��ֵ����ȼ���
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			orgImgA[i][j] = (orgImg.pixelColor(j, i).blue() * 11 + orgImg.pixelColor(j, i).red() * 30 +
	//				orgImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			cohImgA[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//				cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//		}
	//	}
	//	double MSE1 = 0;
	//	double MSE2 = 0;
	//	double PSNR1 = 0;
	//	double PSNR2 = 0;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE1 += (cohImgB[i][j] - orgImgA[i][j])*(cohImgB[i][j] - orgImgA[i][j]);
	//		}
	//	}
	//	MSE1 = MSE1 / (250 * 250);
	//	PSNR1= 10.0*log10((255 * 255) / MSE1);
	//	//qDebug()  << PSNR1;
	//	for (int i = 0; i < 250; i++)
	//	{
	//		for (int j = 0; j < 250; j++)
	//		{
	//			MSE2 += (cohImgA[i][j] - orgImgA[i][j])*(cohImgA[i][j] - orgImgA[i][j]);
	//		}
	//	}
	//	MSE2 = MSE2 / (250 * 250);
	//	PSNR2 = 10.0*log10((255 * 255) / MSE2);
	//	//qDebug() << PSNR2;
	//	orgImg.save("C:/Users/Han/Desktop/Experiment/resultData/"+ originalImgName);
	//	cohImg.save("C:/Users/Han/Desktop/Experiment/resultData/" + pendImageName);
	//}
	//
	/*************************�޸�ͼ���㷨���Խ���*******************************/
	/***********************************��ȡ��ǰĿ¼�µ�����ͼƬ���Կ�ʼ********************/
	//QDir dir("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/");
	//dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
	////dir.setSorting(QDir::Size);

	//QFileInfoList list = dir.entryInfoList();
	///*for (int i = 0; i < list.size(); ++i) {
	//	QFileInfo fileInfo = list.at(i);
	//	qDebug() << qPrintable(QString("%1 %2").arg(fileInfo.size(), 10)
	//		.arg(fileInfo.fileName()));
	//}*/
	//for (int i = 0; i < list.size(); ++i) {
	//	QFileInfo fileInfo = list.at(i);
	//	qDebug() << qPrintable(QString("%1 %2").arg(fileInfo.size(), 10)
	//		.arg(fileInfo.fileName()));
	//}
	//waitKey(0);
	/***********************************��ȡ��ǰĿ¼�µ�����ͼƬ���Խ���********************/
	/***********************************OSTU�㷨���Կ�ʼ***********************************/
	//Mat image = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000487003_.jpg");
	//imshow("SoureImage", image);
	//cvtColor(image, image, CV_RGB2GRAY);
	//Mat imageOutput;
	//Mat imageOtsu;
	//int thresholdValue = OtsuAlgThreshold(image);
	//cout << "��䷽��Ϊ�� " << thresholdValue << endl;
	//threshold(image, imageOutput, thresholdValue, 255, CV_THRESH_BINARY);
	//threshold(image, imageOtsu, 0, 255, CV_THRESH_OTSU); //Opencv Otsu�㷨  
	//													 //imshow("SoureImage",image);  
	//imshow("Output Image", imageOutput);
	//imshow("Opencv Otsu", imageOtsu);
	//waitKey();
	/***********************************OSTU�㷨���Խ���***********************************/
	/***********************************Laplace���Ӳ��Կ�ʼ***************************************************************************/
	/*Mat src, src_gray, dst;
	int kernel_size = 3;
	int scale = 1;
	int delta = 0;
	int ddepth = CV_16S;
	char* window_name = "Laplace Demo";

	int c;

	/// װ��ͼ��
	src = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");

	if (!src.data)
	{
		return -1;
	}

	/// ʹ�ø�˹�˲���������
	GaussianBlur(src, src, Size(3, 3), 0, 0, BORDER_DEFAULT);

	/// ת��Ϊ�Ҷ�ͼ
	cvtColor(src, src_gray, CV_RGB2GRAY);

	/// ������ʾ����
	namedWindow(window_name, CV_WINDOW_AUTOSIZE);

	/// ʹ��Laplace����
	Mat abs_dst;

	Laplacian(src_gray, dst, ddepth, kernel_size, scale, delta, BORDER_DEFAULT);
	convertScaleAbs(dst, abs_dst);

	/// ��ʾ���
	imshow(window_name, abs_dst);

	waitKey(0);*/

	/***********************************���Ӳ��Խ���***************************************************************************/
	/***********************************��Ƶ�ͼ��ָ��㷨2��ʼ*******************************************************************/
	////����һ���ָ�ͼ��Ϊ50*50�Ŀ��С
	//int **imgArray;//����ԭʼͼ��
	//imgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgArray[i] = new int[250];
	//}
	//int **imgMidArray;//����ָ�ͼ�������м����
	//imgMidArray = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray[i] = new int[50];
	//}
	//int **imgMidArray1;//������ɫ�ۺ������м����
	//imgMidArray1 = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray1[i] = new int[50];
	//}
	//int **imgResult;//������
	//imgResult = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgResult[i] = new int[250];
	//}
	//QImage cohImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
	//for (int i = 0; i < 250; i++)
	//{
	//	for (int j = 0; j < 250; j++)
	//	{
	//		imgArray[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//			cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//	}
	//}
	////��ȡȫ����ֵ
	//int highValue = 140;
	//int lowValue = 40;
	///*int highValueSum = 0;
	//int lowValueSum = 0;
	//int numhigh = 0;
	//int numlow = 0;
	//for (int i = 0; i < 250; i++)
	//{
	//	for (int j = 0; j < 250; j++)
	//	{
	//		if (imgArray[i][j] > 125)
	//		{
	//			highValueSum += imgArray[i][j];
	//			numhigh++;
	//		}
	//		else
	//		{
	//			lowValueSum += imgArray[i][j];
	//			numlow++;
	//		}
	//	}
	//}
	//highValue = highValueSum / numhigh;
	//lowValue = lowValueSum / numlow;*/
	//for (int i = 0; i < 25; i++)
	//{
	//	for (int j = 0; j < 25; j++)
	//	{
	//		tool.ImageSeg(imgArray, imgMidArray, i * 10, j * 10, 10);
	//		int  thresholdValue = 0;

	//		thresholdValue = tool.getThresholdValue(imgMidArray, 10, 10, highValue, lowValue);//��ȡÿһ�������ֵ
	//		qDebug() << "i,j" << thresholdValue;
	//		for (int m = i * 10; m < 10 + i * 10; m++)
	//		{
	//			for (int n = j * 10; n < 10 + j * 10; n++)
	//			{
	//				if (imgArray[m][n] > thresholdValue)
	//				{
	//					imgResult[m][n] = 255;
	//				}
	//				else
	//				{
	//					imgResult[m][n] = 0;
	//				}
	//			}
	//		}
	//	}
	//}
	//QImage rImg = tool.toImage(imgResult, 250, 250);
	//rImg.save("C:/Users/Han/Desktop/Experiment/result2.jpg");
	/***********************************��Ƶ�ͼ��ָ��㷨2����*******************************************************************/
	///***********************************��Ƶ�ͼ��ָ��㷨1��ʼ*******************************************************************/
	////����һ���ָ�ͼ��Ϊ50*50�Ŀ��С
	//int **imgArray;//����ԭʼͼ��
	//imgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgArray[i] = new int[250];
	//}
	//int **imgMidArray;//����ָ�ͼ�������м����
	//imgMidArray = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray[i] = new int[50];
	//}
	//int **imgMidArray1;//������ɫ�ۺ������м����
	//imgMidArray1 = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray1[i] = new int[50];
	//}
	//int **imgResult;//������
	//imgResult = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgResult[i] = new int[250];
	//}
	//QImage cohImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
	//for (int i = 0; i < 250; i++)
	//{
	//	for (int j = 0; j < 250; j++)
	//	{
	//		imgArray[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//						cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//	}
	//}
	//for (int i = 0; i < 5; i++)
	//{
	//	for (int j = 0; j < 5; j++)
	//	{
	//		tool.ImageSeg(imgArray,imgMidArray,i*50,j*50,50);
	//		int  thresholdValue = 0;
	//		for (int m = 0; m < 50; m++)
	//		{
	//			for (int n = 0; n < 50; n++)
	//			{
	//				imgMidArray1[m][n] = imgMidArray[m][n] / 20 * 20;
	//			}
	//		}
	//		//thresholdValue = tool.getThresholdValue(imgMidArray1, 50, 50);//��ȡÿһ�������ֵ
	//		//thresholdValue = tool.getThresholdValueWithVarimax(imgMidArray, 50, 50);//��󷽲�����ֵ
	//		thresholdValue = tool.getThresholdValueWithIteration(imgMidArray, 50, 50);//�����������ֵ
	//		for (int m = i * 50; m < 50+i*50; m++)
	//		{
	//			for (int n = j * 50; n < 50+j*50; n++)
	//			{
	//				if (imgArray[m][n] > thresholdValue)
	//				{
	//					imgResult[m][n] = 255;
	//				}
	//				else
	//				{
	//					imgResult[m][n] = 0;
	//				}
	//			}
	//		}
	//	}
	//}
	//QImage rImg=tool.toImage(imgResult,250,250);
	//rImg.save("C:/Users/Han/Desktop/Experiment/result2.jpg");
	///***********************************��Ƶ�ͼ��ָ��㷨1����*******************************************************************/
	/***********************************��Ƶ�ͼ��ָ��㷨3��ʼ*******************************************************************/
	////����һ���ָ�ͼ��Ϊ50*50�Ŀ��С
	//int **imgArray;//����ԭʼͼ��
	//imgArray = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgArray[i] = new int[250];
	//}
	//int **imgMidArray;//����ָ�ͼ�������м����
	//imgMidArray = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray[i] = new int[50];
	//}
	//int **imgMidArray1;//������ɫ�ۺ������м����
	//imgMidArray1 = new int*[50];
	//for (int i = 0; i < 50; i++)
	//{
	//	imgMidArray1[i] = new int[50];
	//}
	//int **imgResult;//������
	//imgResult = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgResult[i] = new int[250];
	//}
	//QImage cohImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
	//for (int i = 0; i < 250; i++)
	//{
	//	for (int j = 0; j < 250; j++)
	//	{
	//		imgArray[i][j] = (cohImg.pixelColor(j, i).blue() * 11 + cohImg.pixelColor(j, i).red() * 30 +
	//			cohImg.pixelColor(j, i).green() * 59 + 50) / 100;
	//	}
	//}
	//int size = 25;//ÿһ��Ĵ�С
	//for (int i = 0; i < 250 / size; i++)
	//{
	//	for (int j = 0; j < 250 / size; j++)
	//	{
	//		tool.ImageSeg(imgArray, imgMidArray, i * size, j * size, size);
	//		int  thresholdValue = 0;
	//		for (int m = 0; m < 25; m++)
	//		{
	//			for (int n = 0; n < 25; n++)
	//			{
	//				imgMidArray1[m][n] = imgMidArray[m][n] / 20 * 20;
	//			}
	//		}
	//		//thresholdValue = tool.getThresholdValue(imgMidArray1, 50, 50);//��ȡÿһ�������ֵ
	//		//thresholdValue = tool.getThresholdValueWithVarimax(imgMidArray, size, size);//��󷽲�����ֵ
	//		//thresholdValue = tool.getThresholdValueWithIteration(imgMidArray, size, size);//�����������ֵ
	//		thresholdValue = tool.getThresholdValueWithOtsu(imgMidArray, size, size);//OSTU�����ֵ
	//		for (int m = i * size; m < size + i * size; m++)
	//		{
	//			for (int n = j * size; n < size + j * size; n++)
	//			{
	//				if (imgArray[m][n] > thresholdValue)
	//				{
	//					imgResult[m][n] = 255;
	//				}
	//				else
	//				{
	//					imgResult[m][n] = 0;
	//				}
	//			}
	//		}
	//	}
	//}
	//int **imgArrayR;//����ԭʼͼ��
	//imgArrayR = new int*[250];
	//for (int i = 0; i < 250; i++)
	//{
	//	imgArrayR[i] = new int[250];
	//}
	//for (int i = 0; i < 250; i++)
	//{
	//	for (int j = 0; j < 250; j++)
	//	{
	//		if (tool.getRadius(imgResult,250,250,i,j)>10)//���ݰ뾶��ȥ��ͼ��
	//		{
	//			imgArrayR[i][j] = 255;
	//		}
	//		else
	//		{
	//			imgArrayR[i][j] = imgResult[i][j];
	//		}
	//	}
	//}

	////QImage rImg = tool.toImage(imgResult, 250, 250);
	//QImage rImg = tool.toImage(imgArrayR, 250, 250);
	//rImg.save("C:/Users/Han/Desktop/Experiment/result3.jpg");
	/***********************************��Ƶ�ͼ��ָ��㷨3����*******************************************************************/

		/*****************************************��ͼ����Ϊ�̶���С��ͼ�����濪ʼ***************************************************/
		//int **imgArray;
		//imgArray = new int*[250];
		//for (int i = 0; i < 250; i++)
		//{
		//	imgArray[i] = new int[250];
		//}
		////QImage cohImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
		//QImage cohImg("C:/Users/Han/Desktop/Experiment/test2.bmp");
		//for (int i = 0; i < 250; i++)
		//{
		//	for (int j = 0; j < 250; j++)
		//	{
		//		imgArray[i][j] = cohImg.pixelColor(j,i).blue();
		//	}
		//}
		//QImage rImg ;
		//for (int i = 0; i < 5; i++)
		//{
		//	for (int j = 0; j < 5; j++)
		//	{
		//		rImg= tool.toImageSeg(imgArray, i * 50, j * 50, 50);
		//		QString s = "C:/Users/Han/Desktop/Experiment/dividWithRegular1/dividAfter";
		//		s.append(QString::number(i*5+j));
		//		s.append(".bmp");
		//		rImg.save(s);
		//	}
		//}
		/*****************************************��ͼ����Ϊ�̶���С��ͼ���������***************************************************/
		/********************************RGB��ɫתΪHSV��ʼ*************************************************************/
		////����ͼ��  
		//Mat image = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
		//Mat hsvimage;

		//cout << "Size:" << image.size() << endl;
		//cout << "Type:" << image.type() << endl;

		///// ��������  
		//namedWindow("BranStarkRGB");
		//namedWindow("BranStarkHSV");

		//cvtColor(image, hsvimage, CV_BGR2HSV);

		///// ��ʾͼ��  
		//imshow("BranStarkRGB", image);
		//imshow("BranStarkHSV", hsvimage);

		//cout << (int)hsvimage.at<Vec3b>(0, 0).type << endl;

		////���һЩֵ���жԱ�  
		//for (int i = 0; i < 10; ++i) {
		//	for (int j = 0; j < 10; ++j) {
		//		cout << "B:" << (int)image.at<Vec3b>(i, j).val[0] << "  G:" << (int)image.at<Vec3b>(i, j).val[1] << "  R:" << (int)image.at<Vec3b>(i, j).val[2] << endl;
		//		cout << "H:" << (int)hsvimage.at<Vec3b>(i, j).val[0] << "  S:" << (int)hsvimage.at<Vec3b>(i, j).val[1] << "  V:" << (int)hsvimage.at<Vec3b>(i, j).val[2] << endl;
		//	}
		//}

		///// �ȴ��û�����  
		//waitKey();
		/********************************RGB��ɫתΪHSV����*************************************************************/

		/*********************************��ɫ�ۺ��������Կ�ʼ***********************************************************/
		//int **imgArray;
		//imgArray = new int*[250];
		//for (int i = 0; i < 250; i++)
		//{
		//	imgArray[i] = new int[250];
		//}
		//QImage cohImg("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
		//for (int i = 0; i < 250; i++)
		//{
		//	for (int j = 0; j < 250; j++)
		//	{
		//		imgArray[i][j] = cohImg.pixelColor(j,i).blue()/20*20;
		//		qDebug() << "color:" << imgArray[i][j];
		//	}
		//}
		//cohImg = tool.toImage(imgArray, 250, 250);
		//cohImg.save("C:/Users/Han/Desktop/Experiment/test2.bmp");
		////����ƽ����
		//int **imgArrayMean;
		//imgArrayMean = new int*[250];
		//for (int i = 0; i < 250; i++)
		//{
		//	imgArrayMean[i] = new int[250];
		//}
		//for (int i = 0; i < 250; i++)
		//{
		//	for (int j = 0; j < 250; j++)
		//	{
		//		if (i == 0 || j == 0 || i == 249 || j == 249)
		//		{
		//			imgArrayMean[i][j] = 255;
		//		}
		//		else
		//		{
		//			imgArrayMean[i][j] = (imgArray[i][j]+ imgArray[i-1][j]
		//				+ imgArray[i+1][j] + imgArray[i][j-1] + imgArray[i][j+1] + imgArray[i-1][j-1]
		//				+ imgArray[i-1][j+1] + imgArray[i+1][j-1] + imgArray[i+1][j+1]) / 9;
		//		}
		//		//imgArrayMean[i][j] = imgArrayMean[i][j]/32*20;
		//	}
		//}
		//QImage cohImg1 = tool.toImage(imgArrayMean,250,250);
		//cohImg1.save("C:/Users/Han/Desktop/Experiment/test3.bmp");
		//waitKey(0);
		/*********************************��ɫ�ۺ��������Խ���***********************************************************/

		/*********************************�ֲ���ֵ����ʼ***************************************************/
		/*image3 = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg", 0);

		if (image3.empty())
		{
			printf("could not load pic!\n");
			return -1;
		}

		namedWindow("image3");

		imshow("image3", image3);

		localTwoValue(image3);

		namedWindow("target3");

		imshow("target3", target3);

		imwrite("C:/Users/Han/Desktop/Experiment/local0000484001_.jpg", target3);

		waitKey(0);*/

		/*********************************�ֲ���ֵ������***************************************************/

		/*******************************�ֲ���ֵ��������ʼ******************************************************************/
		//Mat src, dst;
		//src = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
		//if (src.empty()) {
		//	printf("could not load image...\n");
		//	return -1;
		//}
		//const char* output_tt = "LBP Result";
		//namedWindow("input image", CV_WINDOW_AUTOSIZE);
		//namedWindow(output_tt, CV_WINDOW_AUTOSIZE);
		//imshow("input image", src);

		//// convert to gray

		//cvtColor(src, gray_src, COLOR_BGR2GRAY);
		//int width = gray_src.cols;
		//int height = gray_src.rows;

		//// default LBP image
		//LBP_image = Mat::zeros(src.rows - 2, src.cols - 2, CV_8UC1);
		//for (int row = 1; row < height - 1; row++) {
		//	for (int col = 1; col < width - 1; col++) {
		//		uchar center = gray_src.at<uchar>(row, col);
		//		uchar code = 0;
		//		code |= (gray_src.at<uchar>(row - 1, col - 1) > center) << 7;
		//		code |= (gray_src.at<uchar>(row - 1, col) > center) << 6;
		//		code |= (gray_src.at<uchar>(row - 1, col + 1) > center) << 5;
		//		code |= (gray_src.at<uchar>(row, col + 1) > center) << 4;
		//		code |= (gray_src.at<uchar>(row + 1, col + 1) > center) << 3;
		//		code |= (gray_src.at<uchar>(row + 1, col) > center) << 2;
		//		code |= (gray_src.at<uchar>(row + 1, col - 1) > center) << 1;
		//		code |= (gray_src.at<uchar>(row, col - 1) > center) << 0;
		//		LBP_image.at<uchar>(row - 1, col - 1) = code;
		//	}
		//}

		//imshow(output_tt, LBP_image);

		//// extend LBP 
		//namedWindow("ELBP_Result", CV_WINDOW_AUTOSIZE);
		//createTrackbar("Radius:", "ELBP_Result", &current_radius, max_thresh1, Demo_ELBP);
		//Demo_ELBP(0, 0);
		//imshow("ELBP_Result", ELBP_image);
		//imwrite("C:/Users/Han/Desktop/Experiment/local0000484001_.jpg", ELBP_image);
		//waitKey(0);


		/*******************************�ֲ���ֵ����������******************************************************************/
		/**************************opencv��SVM����������***************************************/
		//// visual representation
		//int width = 512;
		//int height = 512;
		//cv::Mat image = cv::Mat::zeros(height, width, CV_8UC3);

		//// training data
		//int labels[4] = { 1, -1, -1, -1 };
		//float trainingData[4][2] = { { 501, 10 },{ 255, 10 },{ 501, 255 },{ 10, 501 } };
		//cv::Mat trainingDataMat(4, 2, CV_32FC1, trainingData);
		//cv::Mat labelsMat(4, 1, CV_32SC1, labels);

		//// initial SVM
		//cv::Ptr<cv::ml::SVM> svm = cv::ml::SVM::create();
		//svm->setType(cv::ml::SVM::Types::C_SVC);
		//svm->setKernel(cv::ml::SVM::KernelTypes::LINEAR);
		//svm->setTermCriteria(cv::TermCriteria(cv::TermCriteria::MAX_ITER, 100, 1e-6));

		//// train operation
		//svm->train(trainingDataMat, cv::ml::SampleTypes::ROW_SAMPLE, labelsMat);

		//// prediction
		//cv::Vec3b green(0, 255, 0);
		//cv::Vec3b blue(255, 0, 0);
		//for (int i = 0; i < image.rows; i++)
		//{
		//	for (int j = 0; j < image.cols; j++)
		//	{
		//		cv::Mat sampleMat = (cv::Mat_<float>(1, 2) << j, i);
		//		float respose = svm->predict(sampleMat);
		//		if (respose == 1)
		//			image.at<cv::Vec3b>(i, j) = green;
		//		else if (respose == -1)
		//			image.at<cv::Vec3b>(i, j) = blue;
		//	}
		//}

		//int thickness = -1;
		//int lineType = cv::LineTypes::LINE_8;

		//cv::circle(image, cv::Point(501, 10), 5, cv::Scalar(0, 0, 0), thickness, lineType);
		//cv::circle(image, cv::Point(255, 10), 5, cv::Scalar(255, 255, 255), thickness, lineType);
		//cv::circle(image, cv::Point(501, 255), 5, cv::Scalar(255, 255, 255), thickness, lineType);
		//cv::circle(image, cv::Point(10, 501), 5, cv::Scalar(255, 255, 255), thickness, lineType);

		//thickness = 2;
		//lineType = cv::LineTypes::LINE_8;

		//cv::Mat sv = svm->getSupportVectors();
		//for (int i = 0; i < sv.rows; i++)
		//{
		//	const float* v = sv.ptr<float>(i);
		//	cv::circle(image, cv::Point((int)v[0], (int)v[1]), 6, cv::Scalar(128, 128, 128), thickness, lineType);
		//}


		//cv::imshow("SVM Simple Example", image);


		//cv::waitKey(0);
		/**************************opencv��SVM����������***************************************/

		/*==================��ˮ���㷨����===============================*/
		////Mat image = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg", CV_LOAD_IMAGE_COLOR);    //����RGB��ɫͼ��
		//Mat image = imread("C:/Users/Han/Desktop/Experiment/dividWithRegular/dividAfter13.bmp", CV_LOAD_IMAGE_COLOR);
		//namedWindow("MyWindow", CV_WINDOW_AUTOSIZE);
		//imshow("0000484001_.jpg", image);

		////�ҶȻ����˲���Canny��Ե���
		//Mat imageGray;
		//cvtColor(image, imageGray, CV_RGB2GRAY);//�Ҷ�ת��
		//GaussianBlur(imageGray, imageGray, Size(5, 5), 2);   //��˹�˲�
		//imshow("Gray Image", imageGray);
		//Canny(imageGray, imageGray, 80, 150);
		//imshow("Canny Image", imageGray);
		////��������
		//vector<vector<Point>> contours;
		//vector<Vec4i> hierarchy;
		//findContours(imageGray, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point());
		//Mat imageContours = Mat::zeros(image.size(), CV_8UC1);  //����
		//Mat marks(image.size(), CV_32S);   //Opencv��ˮ��ڶ����������
		//marks = Scalar::all(0);
		//int index = 0;
		//int compCount = 0;
		//for (; index >= 0; index = hierarchy[index][0], compCount++)
		//{
		//	//��marks���б�ǣ��Բ�ͬ������������б�ţ��൱������עˮ�㣬�ж������������ж���עˮ��
		//	drawContours(marks, contours, index, Scalar::all(compCount + 1), 1, 8, hierarchy);
		//	drawContours(imageContours, contours, index, Scalar(255), 1, 8, hierarchy);
		//}

		////��������һ�´���ľ���marks����ʲô����
		//Mat marksShows;
		//convertScaleAbs(marks, marksShows);
		//imshow("marksShow", marksShows);
		//imwrite("C:/Users/Han/Desktop/Experiment/testImage/watershed0000484001_marksShow.jpg", marksShows);
		//imshow("����", imageContours);
		//imwrite("C:/Users/Han/Desktop/Experiment/testImage/watershed0000484001_outline .jpg", imageContours);
		//watershed(image, marks);


		////����������һ�·�ˮ���㷨֮��ľ���marks����ʲô����
		//Mat afterWatershed;
		//convertScaleAbs(marks, afterWatershed);
		//imshow("After Watershed", afterWatershed);
		//imwrite("C:/Users/Han/Desktop/Experiment/testImage/watershed0000484001_AfterWatershed.jpg", afterWatershed);
		////��ÿһ�����������ɫ���
		//Mat PerspectiveImage = Mat::zeros(image.size(), CV_8UC3);
		//for (int i = 0; i<marks.rows; i++)
		//{
		//	for (int j = 0; j<marks.cols; j++)
		//	{
		//		int index = marks.at<int>(i, j);
		//		if (marks.at<int>(i, j) == -1)
		//		{
		//			PerspectiveImage.at<Vec3b>(i, j) = Vec3b(255, 255, 255);
		//		}
		//		else
		//		{
		//			PerspectiveImage.at<Vec3b>(i, j) = RandomColor(index);
		//		}
		//	}
		//}
		//imshow("After ColorFill", PerspectiveImage);
		//imwrite("C:/Users/Han/Desktop/Experiment/testImage/watershed0000484001_AfterColorFill.jpg", PerspectiveImage);
		////�ָ�����ɫ�Ľ����ԭʼͼ���ں�
		//Mat wshed;
		//addWeighted(image, 0.4, PerspectiveImage, 0.6, 0, wshed);
		//imshow("AddWeighted Image", wshed);
		//imwrite("C:/Users/Han/Desktop/Experiment/testImage/watershed0000484001_AddWeightedImage.jpg", wshed);
		//waitKey();
		/*====================��ˮ���㷨����OpenCV����==========================*/

		/******************************��ֵ��λ�ָ���Կ�ʼ*******************************************/
		//cv::Mat srcImg = imread("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
		//if (srcImg.empty())
		//	return -1;
		//// �����趨  
		//int spatialRad = 20;
		//int colorRad = 20;
		//int maxPyrLevel = 6;
		//cv::Mat resImg;
		//// ��ֵƯ�Ʒָ�  
		//pyrMeanShiftFiltering(srcImg, resImg,
		//	spatialRad, colorRad, maxPyrLevel);
		//// ��ɫͨ������ϲ�  
		//MergeSeg(resImg, Scalar::all(2));
		//cv::imshow("src", srcImg);
		//cv::imshow("resImg", resImg);
		//cv::waitKey();
		/******************************��ֵ��λ�ָ���Խ���*******************************************/

		/*========================����ͼ�۵ķָ��㷨���Կ�ʼ================================*/
		////����ͼ��  
		////
		////const char* imagename = "G:\\Pic\\101087_big.jpg";  
		//const char* imagename = "C:/Users/Han/Desktop/Experiment/dividWithRegular/dividAfter13.bmp";
		////const char* imagename = "grain.bmp";  
		////const char* imagename = "person_272.png";  
		////���ļ��ж���ͼ��  
		//Mat img = imread(imagename);

		////�������ͼ��ʧ��  
		//if (img.empty())
		//{
		//	fprintf(stderr, "Can not load image %s\n", imagename);
		//	return -1;
		//}

		////��ʾͼ��  
		//imshow("image", img);
		////cvtColor(img, img, CV_BGR2Lab);// May be using lab color space will be better  
		//Mat gray;
		//cvtColor(img, gray, CV_BGR2GRAY);
		//img.convertTo(img, CV_32FC3);

		//float sigma = 0.5;
		//float k = 500;
		//int min_size = 100;
		//int num_ccs;
		//clock_t tt = clock();
		//Mat result = segment_image(img, sigma, k, min_size, &num_ccs);


		//tt = clock() - tt;
		//float process_time = (float)tt / CLOCKS_PER_SEC;
		//cout << "get " << num_ccs << " components" << endl;

		//cout << "process time: " << process_time << endl;
		//imshow("process result", result);

		//cvtColor(gray, gray, CV_GRAY2BGR);
		//imshow("overlay result", gray*0.25 + result*0.75);

		////�˺����ȴ�������������������ͷ���  
		//waitKey();
		/*=================================����ͼ�۵ķָ��㷨���Խ���==============================================*/





		//Tool tool;
		////QImage image("C:/Users/Han/Desktop/Experiment/test.jpg"); 
		////QImage image("C:/Users/Han/Desktop/Experiment/testImage/Robertstest1.jpg");
		//QImage image("C:/Users/Han/Desktop/Experiment/testSave.jpg");
		///*תΪ�ڰ�ͼƬ�����浽������*/
		//int width = image.width();
		//int height = image.height();
		//int **img;
		//img = new int*[height];
		//for (int i = 0; i < width; i++)
		//{
		//	img[i] = new int[width];
		//}
		//for (int i = 0; i < height; i++)
		//{
		//	QPoint tempPoint;
		//	QColor tempColor;
		//	for (int j = 0; j < width; j++)
		//	{
		//		tempPoint = QPoint(j, i);
		//		tempColor = image.pixelColor(tempPoint);
		//		img[i][j] = (tempColor.blue() * 11 + tempColor.red() * 30 + tempColor.green() * 59 + 50) / 100;
		//		//img[i][j] = tempColor.blue()*1.5;
		//		//img[i][j] = tempColor.red();
		//		//img[i][j] = tempColor.green();
		//	}
		//}



		///*�Զ�����ͼƬ�㷨*/
		///*int width = image.width();
		//int height = image.height();
		//QImage rImg = QImage(width, height, QImage::Format_Indexed8);
		//for (int i = 0; i < 100; i++)
		//{
		//	rImg = toGray(image, 0.0+0.03*i);
		//	QString s = "C:/Users/Han/Desktop/Experiment/testImage/testBlue";
		//	s.append(QString::number(i));
		//	s.append(".jpg");
		//	rImg.save(s);
		//}*/


		/******************���ݵ���ֵ�Զ��ָ�ͼ��ʼ****************************************/
		//QImage rImg = QImage(250, 250, QImage::Format_Indexed8);
		////QImage image("C:/Users/Han/Desktop/Experiment/divideImage/test36.bmp");
		//QImage rImage("C:/Users/Han/Desktop/Experiment/fuseImgTest.bmp");
		//for (int i = 10; i < 255; i++)
		//{
		//	rImg = tool.segmentation(rImage, i);
		//	QString s = "C:/Users/Han/Desktop/Experiment/dividWithRegular/sigleTest/divid";
		//	s.append(QString::number(i));
		//	s.append(".bmp");
		//	rImg.save(s);
		//}
		/*******************���ݵ���ֵ�Զ��ָ�ͼ�����**************************************************************/

		/******************����˫��ֵ�Զ��ָ�ͼ��ʼ****************************************/
		//QImage orgImg = QImage(250, 250, QImage::Format_Indexed8);
		//// orgImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg");
		//QImage orgImage("C:/Users/Han/Desktop/Experiment/fuseImgTest.bmp");
		//for (int i = 0; i < 200; i++)
		//{
		//	for (int j = i + 2; j < 202; j++)
		//	{
		//		orgImg = tool.segmentation(orgImage, i, j);
		//		QString s = "C:/Users/Han/Desktop/Experiment/dividWithRegular/sigleTest/divid";
		//		s.append(QString::number(i));
		//		s.append("_");
		//		s.append(QString::number(j));
		//		s.append(".bmp");
		//		orgImg.save(s);
		//	}
		//}
		/**********************************˫��ֵ�Զ��ָ����***********************************************/

		/***********************************��ȡͼ���ֱ��ͼ��ʼ********************************************************/
		//QString path = "C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg";
		//QString path = "C:/Users/Han/Desktop/Experiment/dividWithRegular1/dividAfter5.bmp";
		//const char* imageName;
		//QByteArray ba = path.toLatin1(); // must
		//imageName = ba.data();
		//Mat imgTmp = imread(imageName);//��ȡͼ��
		//Mat grayTmp;
		//cvtColor(imgTmp, grayTmp, CV_BGR2GRAY);//תΪ�Ҷ�ͼ
		////imwrite("C:/Users/Han/Desktop/Experiment/dividWithRegular/dividAfter0grayImage.bmp", grayTmp);
		//imgTmp = histGray(grayTmp);
		//imwrite("C:/Users/Han/Desktop/Experiment/dividWithRegular1/dividAfter5histImage.bmp", imgTmp);
		/***********************************��ȡͼ���ֱ��ͼ����********************************************************/

		/***************************************��QImage�ķ�ʽ����Ҷ�ͼ��ʼ******************************************************************/
		/*QImage tImage("C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000487008_.jpg");
		tImage = tool.toGray(tImage);
		tImage.save("C:/Users/Han/Desktop/Experiment/grayImage1.jpg");*/
		/***************************************��QImage�ķ�ʽ����Ҷ�ͼ����******************************************************************/
		/**********************ֱ��ͼ��ֵ�����Կ�ʼ***************************************************/
		/*src = imread("C:/Users/Han/Desktop/Experiment/testImage/test20_.bmp");

		/// Convert image to gray and blur it
		cvtColor(src, src_gray, CV_BGR2GRAY);
		blur(src_gray, src_gray, Size(3, 3));

		/// Create Window
		char* source_window = "C:/Users/Han/Desktop/Experiment/testImage/test20_.bmp";
		namedWindow(source_window, CV_WINDOW_AUTOSIZE);
		imshow(source_window, src_gray);

		createTrackbar(" Threshold:", "C:/Users/Han/Desktop/Experiment/AI_CV_Test_1/0000484001_.jpg", &thresh, max_thresh, thresh_callback);
		thresh_callback(0, 0);

		waitKey(0);*/
		/**********************ֱ��ͼ��ֵ�����Խ���***************************************************/

		/********************************************�߽�����㷨��ʼ************************************************/
		////QPoint startPoint(249, 27);
		//QPoint startPoint(224, 1);
		//bool isOver = false;
		//int m = 224;
		//int n = 1;
		//int  thresholdValue = 35;
		//int i = 0;
		//int count = 0;
		///*while (!isOver)
		//{
		//	if (count < 100) {
		//		count++;
		//		int number = 0;//��¼
		//		for (; i < 8; i++)
		//		{
		//			number++;
		//			i = i % 8;
		//			isOver = true;
		//			switch (i)
		//			{
		//			case 0:
		//			{
		//				if (img[m][n + 1] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m;
		//					n = n + 1;
		//					i = -1;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			case 1:
		//			{
		//				if (img[m - 1][n + 1] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m - 1;
		//					n = n + 1;
		//					i = 0;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			case 2:
		//			{
		//				if (img[m - 1][n] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m - 1;
		//					n = n;
		//					i = 1;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			case 3:
		//			{
		//				if (img[m - 1][n - 1] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m - 1;
		//					n = n - 1;
		//					i = 2;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			case 4:
		//			{
		//				if (img[m][n - 1] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m;
		//					n = n - 1;
		//					i = 3;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			case 5:
		//			{
		//				if (img[m + 1][n - 1] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m + 1;
		//					n = n - 1;
		//					i = 4;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			case 6:
		//			{
		//				if (img[m + 1][n] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m + 1;
		//					n = n;
		//					i = 5;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			case 7:
		//			{
		//				if (img[m + 1][n + 1] - img[m][n] < thresholdValue)
		//				{
		//					img[m][n] = 0;
		//					m = m + 1;
		//					n = n + 1;
		//					i = 6;
		//					isOver = false;
		//				}
		//				break;
		//			}
		//			default:
		//				break;
		//			}
		//			qDebug() << "m:" << m << "n:" << n;
		//			if (number == 8)
		//			{
		//				break;
		//			}
		//			if (m <=0 || n <= 0 || m >=254 || n >=254)
		//			{
		//				isOver = true;
		//				break;
		//			}
		//		}
		//	}
		//}
		//*/

		///*=======================�߽���ٲ�������==================*/
		//int **testImg;
		//testImg = new int*[5];
		//for (int i = 0; i < 5; i++)
		//{
		//	testImg[i] = new int[5];
		//}
		//testImg[0][0] = 0; testImg[0][1] = 0; testImg[0][2] = 0; testImg[0][3] = 0; testImg[0][4] = 0;
		//testImg[1][0] = 0; testImg[1][1] = 0; testImg[1][2] = 255; testImg[1][3] = 255; testImg[1][4] = 0;
		//testImg[2][0] = 0; testImg[2][1] = 255; testImg[2][2] = 255; testImg[2][3] = 255; testImg[2][4] = 0;
		//testImg[3][0] = 0; testImg[3][1] = 0; testImg[3][2] = 255; testImg[3][3] = 0; testImg[3][4] = 0;
		//testImg[4][0] = 0; testImg[4][1] = 0; testImg[4][2] = 0; testImg[4][3] = 0; testImg[4][4] = 0;
		//int **copyImg1;
		//copyImg1 = new int*[250];
		//for (int i = 0; i < 250; i++)
		//{
		//	copyImg1[i] = new int[250];
		//}
		//searchTest(2, 2, testImg);
		//for (int i = 0; i < 5; i++)
		//{
		//	qDebug() << "================================================" << i;
		//	for (int j = 0; j < 5; j++)
		//	{
		//		copyImage1(copyImg1, testImg);
		//		if (searchTest(i, j, testImg) == false)
		//		{
		//			qDebug() << "false";
		//			copyImage1(testImg, copyImg1);
		//		}
		//		else
		//		{
		//			qDebug() << "true";
		//		}
		//	}
		//}
		//for (int i = 0; i < 5; i++)
		//{
		//	qDebug() << "��" << i << "��";
		//	for (int j = 0; j < 5; j++)
		//	{
		//		qDebug() << testImg[i][j];
		//	}
		//}
		///*����Ϊ����*/


		///*��ֵ��*/
		////QImage rImg = QImage(width, height, QImage::Format_Indexed8);
		//rImg.setColorCount(256);
		//for (int i = 0; i < 256; i++)
		//{
		//	rImg.setColor(i, qRgb(i, i, i));
		//}
		//for (int i = 0; i < height; i++)
		//{
		//	for (int j = 0; j < width; j++)
		//	{
		//		if (255 - img[i][j] < img[i][j] - 0)
		//		{
		//			img[i][j] = 255;
		//		}
		//		else
		//		{
		//			img[i][j] = 0;
		//		}
		//		rImg.setPixel(j, i, img[i][j]);

		//	}
		//}
		//int **copyImg;
		//copyImg = new int*[250];
		//for (int i = 0; i < 250; i++)
		//{
		//	copyImg[i] = new int[250];
		//}


		//for (int i = 0; i < 249; i++)
		//{
		//	qDebug() << "================================================"<<i;
		//	for (int j = 0; j < 249; j++)
		//	{
		//		copyImage(copyImg, img);
		//		if (search(i, j, img) == false)
		//		{
		//			qDebug() << "false";
		//			copyImage(img, copyImg);
		//		}
		//		else
		//		{
		//			qDebug() << "true";
		//		}
		//	}
		//}

		//for (int i = 0; i < height; i++)
		//{
		//	for (int j = 0; j < width; j++)
		//	{
		//		rImg.setPixel(j, i, img[i][j]);

		//	}
		//}


		//rImg.save("C:/Users/Han/Desktop/Experiment/getResult123.jpg");
		/************************�߽���ٽ���***************************************/
	imageEdgeTracing w;
	w.show();
	return a.exec();
}

bool search(int x, int y, int **img)
{
	int count = 0;
	if (x == 0 || x == 249 || y == 0 || y == 249)
	{
		count = 0;
		return false;
	}
	int i = 0;
	if (img[x][y + 1] == 255)
	{
		img[x][y + 1] = 0;
		count++;
		if (count > 4)
		{
			count = 0;
			return false;
		}
		i++;
		return search(x, y + 1, img);
	}
	if (img[x - 1][y] == 255)
	{
		img[x - 1][y] = 0;
		count++;
		if (count > 4)
		{
			count = 0;
			return false;
		}
		i++;
		return search(x - 1, y, img);
	}
	if (img[x][y - 1] == 255)
	{
		img[x][y - 1] = 0;
		count++;
		if (count > 4)
		{
			count = 0;
			return false;
		}
		i++;
		return search(x, y - 1, img);

	}
	if (img[x + 1][y] == 255)
	{
		img[x + 1][y] = 0;
		count++;
		if (count > 4)
		{
			count = 0;
			return false;
		}
		i++;
		return search(x + 1, y, img);
	}
	if (i == 0)
	{
		count = 0;
		return true;
	}
	//return false;
}

bool searchTest(int x, int y, int **img)
{
	if (x == 0 || x == 4 || y == 0 || y == 4)
	{
		return false;
	}
	int i = 0;
	if (img[x][y + 1] == 255)
	{
		img[x][y + 1] = 0;
		i++;
		return searchTest(x, y + 1, img);
	}
	if (img[x - 1][y] == 255)
	{
		img[x - 1][y] = 0;
		i++;
		return searchTest(x - 1, y, img);
	}
	if (img[x][y - 1] == 255)
	{
		img[x][y - 1] = 0;
		i++;
		return searchTest(x, y - 1, img);

	}
	if (img[x + 1][y] == 255)
	{
		img[x + 1][y] = 0;
		i++;
		return searchTest(x + 1, y, img);
	}
	if (i == 0)
	{
		return true;
	}
	return false;
}

void copyImage(int **copyImg, int **img)
{
	for (int i = 0; i < 250; i++)
	{
		for (int j = 0; j < 250; j++)
		{
			copyImg[i][j] = img[i][j];
		}
	}
}

void copyImage1(int **copyImg, int **img)
{
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			copyImg[i][j] = img[i][j];
		}
	}
}


Vec3b RandomColor(int value)
{
	value = value % 255;  //����0~255�������  
	RNG rng;
	int aa = rng.uniform(0, value);
	int bb = rng.uniform(0, value);
	int cc = rng.uniform(0, value);
	return Vec3b(aa, bb, cc);
}

Mat getHistImg(const MatND& hist)
{
	double maxVal = 0;
	double minVal = 0;

	//�ҵ�ֱ��ͼ�е����ֵ����Сֵ
	minMaxLoc(hist, &minVal, &maxVal, 0, 0);
	int histSize = hist.rows;
	Mat histImg(histSize, histSize, CV_8U, Scalar(255));
	// ��������ֵΪͼ��߶ȵ�90%
	int hpt = static_cast<int>(1 * histSize);

	for (int h = 0; h < histSize; h++)
	{
		float binVal = hist.at<float>(h);
		int intensity = static_cast<int>(binVal*hpt / maxVal);
		line(histImg, Point(h, histSize), Point(h, histSize - intensity), Scalar::all(0));
	}

	return histImg;
}

Mat histGray(Mat image)
{
	//��ʾƵ�ʷֲ�ֱ��ͼ
	const int channels[1] = { 0 };
	const int histSize[1] = { 256 };
	float hranges[2] = { 0,255 };
	const float* ranges[1] = { hranges };
	MatND hist;
	calcHist(&image, 1, channels, Mat(), hist, 1, histSize, ranges);
	Mat histShow;
	histShow = getHistImg(hist);
	return histShow;
}

Mat histColor(Mat image)
{
	const int channels[3] = { 0,1,2 };
	const int histSize[3] = { 256,256,256 };
	float hranges[2] = { 0,255 };
	const float* ranges[3] = { hranges,hranges,hranges };
	MatND hist;
	calcHist(&image, 1, channels, Mat(), hist, 3, histSize, ranges);
	Mat histShow;
	histShow = getHistImg(hist);
	return histShow;
}

int getSecondCrest(QString s)
{
	QImage img(s);
	int width = img.width();
	int height = img.height();
	int **imgHistogram;
	imgHistogram = new int*[height];
	for (int i = 0; i < height; i++)
	{
		imgHistogram[i] = new int[width];
	}

	for (int i = 0; i < height; i++)
	{
		QPoint tempPoint;
		QColor tempColor;
		for (int j = 0; j < width; j++)
		{
			tempPoint = QPoint(j, i);
			tempColor = img.pixelColor(tempPoint);
			imgHistogram[i][j] = (tempColor.blue() * 11 + tempColor.red() * 30 + tempColor.green() * 59 + 50) / 100;
		}
	}
	/*for (int i = 0; i < width; i++)
	{
		qDebug() << "==========================" << i;
		for (int j = 0; j < height; j++)
		{
			qDebug() << imgHistogram[i][j];
		}

	}*/

	int *count;
	count = new int[width];
	int *possibleValues;
	possibleValues = new int[width];
	for (int i = 0; i < width; i++)
	{
		possibleValues[i] = 0;
	}
	int possibleunm = 0;
	for (int i = 0; i < width; i++)//ͳ��ÿһ�е�����
	{
		int num = 0;
		for (int j = 0; j < height; j++)
		{
			if (imgHistogram[j][i] < 1)
			{
				num++;
			}
		}
		count[i] = num;
	}
	/*for (int i = 0; i < width; i++)
	{
		qDebug() << i << ":" << count[i];
	}*/

	int positon = width - 1;
	int k = 0;
	int max = count[width - 1];
	for (int i = width - 1; i--; i > 0)
	{

		if (count[i] > max)
		{
			max = count[i];
			positon = i;
			k++;
			k = 0;
		}
		k++;
		if (k > 20)
		{
			possibleValues[possibleunm++] = positon;
			max = 0;
			k = 0;
		}
	}


	for (int i = 0; i < width; i++)
	{
		if (possibleValues[i] != 0)
		{
			possibleValues[i] = count[possibleValues[i]];
		}
	}
	/*for (int i = 0; i < width; i++)
	{
		qDebug() << "fafaafa:" << possibleValues[i];
	}*/
	int posibleMax = 0;
	for (int i = 0; i < width - 1; i++)
	{
		posibleMax = possibleValues[i];
		for (int j = i + 1; j < width; j++)
		{
			if (possibleValues[j] > posibleMax)
			{
				posibleMax = possibleValues[j];
				int t = possibleValues[j];
				possibleValues[j] = possibleValues[i];
				possibleValues[i] = t;

			}
		}
	}
	/*for (int i = 0; i < width; i++)
	{
		qDebug() << "fafaafa:" << possibleValues[i];
	}*/
	return possibleValues[0] - 20;
}


/** @function thresh_callback */
void thresh_callback(int, void*)
{
	Mat src_copy = src.clone();
	Mat threshold_output;
	vector<vector<Point> > contours;
	vector<Vec4i> hierarchy;

	/// Detect edges using Threshold  
	threshold(src_gray, threshold_output, thresh, 255, THRESH_BINARY);

	/// Find contours  
	findContours(threshold_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));

	/// Find the convex hull object for each contour  
	vector<vector<Point> >hull(contours.size());
	// Int type hull  
	vector<vector<int>> hullsI(contours.size());
	// Convexity defects  
	vector<vector<Vec4i>> defects(contours.size());

	for (size_t i = 0; i < contours.size(); i++)
	{
		convexHull(Mat(contours[i]), hull[i], false);
		// find int type hull  
		convexHull(Mat(contours[i]), hullsI[i], false);
		// get convexity defects  
		convexityDefects(Mat(contours[i]), hullsI[i], defects[i]);

	}

	/// Draw contours + hull results  
	Mat drawing = Mat::zeros(threshold_output.size(), CV_8UC3);
	for (size_t i = 0; i < contours.size(); i++)
	{
		Scalar color = Scalar(rng.uniform(0, 255), rng.uniform(0, 255), rng.uniform(0, 255));
		drawContours(drawing, contours, i, color, 1, 8, vector<Vec4i>(), 0, Point());
		drawContours(drawing, hull, i, color, 1, 8, vector<Vec4i>(), 0, Point());

		// draw defects  
		size_t count = contours[i].size();
		std::cout << "Count : " << count << std::endl;
		if (count < 300)
			continue;

		vector<Vec4i>::iterator d = defects[i].begin();

		while (d != defects[i].end()) {
			Vec4i& v = (*d);
			//if(IndexOfBiggestContour == i)  
			{

				int startidx = v[0];
				Point ptStart(contours[i][startidx]); // point of the contour where the defect begins  
				int endidx = v[1];
				Point ptEnd(contours[i][endidx]); // point of the contour where the defect ends  
				int faridx = v[2];
				Point ptFar(contours[i][faridx]);// the farthest from the convex hull point within the defect  
				int depth = v[3] / 256; // distance between the farthest point and the convex hull  

				if (depth > 20 && depth < 80)
				{
					line(drawing, ptStart, ptFar, CV_RGB(0, 255, 0), 2);
					line(drawing, ptEnd, ptFar, CV_RGB(0, 255, 0), 2);
					circle(drawing, ptStart, 4, Scalar(255, 0, 100), 2);
					circle(drawing, ptEnd, 4, Scalar(255, 0, 100), 2);
					circle(drawing, ptFar, 4, Scalar(100, 0, 255), 2);
				}

				/*printf("start(%d,%d) end(%d,%d), far(%d,%d)\n",
				ptStart.x, ptStart.y, ptEnd.x, ptEnd.y, ptFar.x, ptFar.y);*/
				qDebug() << "ptStart" << ptStart.x << "ptStart" << ptStart.y << "ptEnd" << ptEnd.x << "ptEnd" << ptEnd.y;
			}
			d++;
		}


	}

	/// Show in a window  
	namedWindow("Hull demo", CV_WINDOW_AUTOSIZE);
	imshow("Hull demo", drawing);
	//imwrite("convexity_defects.jpg", drawing);  
}

void Demo_ELBP(int, void*) {
	int offset = current_radius * 2;
	ELBP_image = Mat::zeros(gray_src.rows - offset, gray_src.cols - offset, CV_8UC1);
	int height = gray_src.rows;
	int width = gray_src.cols;

	int neighbors = 8;
	for (int n = 0; n < neighbors; n++) {
		// sample points
		float x = static_cast<float>(current_radius) * cos(2.0*CV_PI*n / static_cast<float>(neighbors));
		float y = static_cast<float>(current_radius) * -sin(2.0*CV_PI*n / static_cast<float>(neighbors));
		// relative indices
		int fx = static_cast<int>(floor(x));
		int fy = static_cast<int>(floor(y));
		int cx = static_cast<int>(ceil(x));
		int cy = static_cast<int>(ceil(y));
		// fractional part
		float ty = y - fy;
		float tx = x - fx;
		// set interpolation weights
		float w1 = (1 - tx) * (1 - ty);
		float w2 = tx  * (1 - ty);
		float w3 = (1 - tx) *      ty;
		float w4 = tx  *      ty;
		// iterate through your data
		for (int i = current_radius; i < gray_src.rows - current_radius; i++) {
			for (int j = current_radius; j < gray_src.cols - current_radius; j++) {
				float t = w1*gray_src.at<uchar>(i + fy, j + fx) + w2*gray_src.at<uchar>(i + fy, j + cx) + w3*gray_src.at<uchar>(i + cy, j + fx) + w4*gray_src.at<uchar>(i + cy, j + cx);
				// we are dealing with floating point precision, so add some little tolerance
				ELBP_image.at<uchar>(i - current_radius, j - current_radius) += ((t > gray_src.at<uchar>(i, j)) && (abs(t - gray_src.at<uchar>(i, j)) > std::numeric_limits<float>::epsilon())) << n;
			}
		}
	}
}

