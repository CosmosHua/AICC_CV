#pragma once
#include "opencv2/opencv.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/ml.hpp"
class Mysvm : public CvSVM
{
public:
	int get_alpha_count()
	{
		return this->sv_total;
	}

	int get_sv_dim()
	{
		return this->var_all;
	}

	int get_sv_count()
	{
		return this->decision_func->sv_count;
	}

	double* get_alpha()
	{
		return this->decision_func->alpha;
	}

	float** get_sv()
	{
		return this->sv;
	}

	float get_rho()
	{
		return this->decision_func->rho;
	}
};

void Train()
{
	char classifierSavePath[256] = "c:/pedestrianDetect-peopleFlow.txt";

	string positivePath = "E:\\pictures\\train1\\pos\\";
	string negativePath = "E:\\pictures\\train1\\neg\\";

	int positiveSampleCount = 4900;
	int negativeSampleCount = 6192;
	int totalSampleCount = positiveSampleCount + negativeSampleCount;

	cout << "//////////////////////////////////////////////////////////////////" << endl;
	cout << "totalSampleCount: " << totalSampleCount << endl;
	cout << "positiveSampleCount: " << positiveSampleCount << endl;
	cout << "negativeSampleCount: " << negativeSampleCount << endl;

	CvMat *sampleFeaturesMat = cvCreateMat(totalSampleCount, 1764, CV_32FC1);
	//64*128��ѵ���������þ�����totalSample*3780,64*64��ѵ���������þ�����totalSample*1764  
	cvSetZero(sampleFeaturesMat);
	CvMat *sampleLabelMat = cvCreateMat(totalSampleCount, 1, CV_32FC1);//������ʶ    
	cvSetZero(sampleLabelMat);

	cout << "************************************************************" << endl;
	cout << "start to training positive samples..." << endl;

	char positiveImgName[256];
	string path;
	for (int i = 0; i<positiveSampleCount; i++)
	{
		memset(positiveImgName, '\0', 256 * sizeof(char));
		sprintf(positiveImgName, "%d.jpg", i);
		int len = strlen(positiveImgName);
		string tempStr = positiveImgName;
		path = positivePath + tempStr;

		cv::Mat img = cv::imread(path);
		if (img.data == NULL)
		{
			cout << "positive image sample load error: " << i << " " << path << endl;
			system("pause");
			continue;
		}

		cv::HOGDescriptor hog(cv::Size(64, 64), cv::Size(16, 16), cv::Size(8, 8), cv::Size(8, 8), 9);
		vector<float> featureVec;

		hog.compute(img, featureVec, cv::Size(8, 8));
		int featureVecSize = featureVec.size();

		for (int j = 0; j<featureVecSize; j++)
		{
			CV_MAT_ELEM(*sampleFeaturesMat, float, i, j) = featureVec[j];
		}
		sampleLabelMat->data.fl[i] = 1;
	}
	cout << "end of training for positive samples..." << endl;

	cout << "*********************************************************" << endl;
	cout << "start to train negative samples..." << endl;

	char negativeImgName[256];
	for (int i = 0; i<negativeSampleCount; i++)
	{
		memset(negativeImgName, '\0', 256 * sizeof(char));
		sprintf(negativeImgName, "%d.jpg", i);
		path = negativePath + negativeImgName;
		cv::Mat img = cv::imread(path);
		if (img.data == NULL)
		{
			cout << "negative image sample load error: " << path << endl;
			continue;
		}

		cv::HOGDescriptor hog(cv::Size(64, 64), cv::Size(16, 16), cv::Size(8, 8), cv::Size(8, 8), 9);
		vector<float> featureVec;

		hog.compute(img, featureVec, cv::Size(8, 8));//����HOG����  
		int featureVecSize = featureVec.size();

		for (int j = 0; j<featureVecSize; j++)
		{
			CV_MAT_ELEM(*sampleFeaturesMat, float, i + positiveSampleCount, j) = featureVec[j];
		}

		sampleLabelMat->data.fl[i + positiveSampleCount] = -1;
	}

	cout << "end of training for negative samples..." << endl;
	cout << "********************************************************" << endl;
	cout << "start to train for SVM classifier..." << endl;

	CvSVMParams params;
	params.svm_type = CvSVM::C_SVC;
	params.kernel_type = CvSVM::LINEAR;
	params.term_crit = cvTermCriteria(CV_TERMCRIT_ITER, 1000, FLT_EPSILON);
	params.C = 0.01;

	Mysvm svm;
	svm.train(sampleFeaturesMat, sampleLabelMat, NULL, NULL, params); //��SVM���Է�����ѵ��  
	svm.save(classifierSavePath);

	cvReleaseMat(&sampleFeaturesMat);
	cvReleaseMat(&sampleLabelMat);

	int supportVectorSize = svm.get_support_vector_count();
	cout << "support vector size of SVM��" << supportVectorSize << endl;
	cout << "************************ end of training for SVM ******************" << endl;

	CvMat *sv, *alp, *re;//����������������   
	sv = cvCreateMat(supportVectorSize, 1764, CV_32FC1);
	alp = cvCreateMat(1, supportVectorSize, CV_32FC1);
	re = cvCreateMat(1, 1764, CV_32FC1);
	CvMat *res = cvCreateMat(1, 1, CV_32FC1);

	cvSetZero(sv);
	cvSetZero(re);

	for (int i = 0; i<supportVectorSize; i++)
	{
		memcpy((float*)(sv->data.fl + i * 1764), svm.get_support_vector(i), 1764 * sizeof(float));
	}

	double* alphaArr = svm.get_alpha();
	int alphaCount = svm.get_alpha_count();

	for (int i = 0; i<supportVectorSize; i++)
	{
		alp->data.fl[i] = alphaArr[i];
	}
	cvMatMul(alp, sv, re);

	int posCount = 0;
	for (int i = 0; i<1764; i++)
	{
		re->data.fl[i] *= -1;
	}

	FILE* fp = fopen("c:/hogSVMDetector-peopleFlow.txt", "wb");
	if (NULL == fp)
	{
		return 1;
	}
	for (int i = 0; i<1764; i++)
	{
		fprintf(fp, "%f \n", re->data.fl[i]);
	}
	float rho = svm.get_rho();
	fprintf(fp, "%f", rho);
	cout << "c:/hogSVMDetector.txt �������" << endl;//����HOG��ʶ��ķ�����  
	fclose(fp);

	return 1;
}