/********************************************************************************
** Form generated from reading UI file 'imageEdgeTracing.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMAGEEDGETRACING_H
#define UI_IMAGEEDGETRACING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_imageEdgeTracingClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *imageEdgeTracingClass)
    {
        if (imageEdgeTracingClass->objectName().isEmpty())
            imageEdgeTracingClass->setObjectName(QStringLiteral("imageEdgeTracingClass"));
        imageEdgeTracingClass->resize(600, 400);
        menuBar = new QMenuBar(imageEdgeTracingClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        imageEdgeTracingClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(imageEdgeTracingClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        imageEdgeTracingClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(imageEdgeTracingClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        imageEdgeTracingClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(imageEdgeTracingClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        imageEdgeTracingClass->setStatusBar(statusBar);

        retranslateUi(imageEdgeTracingClass);

        QMetaObject::connectSlotsByName(imageEdgeTracingClass);
    } // setupUi

    void retranslateUi(QMainWindow *imageEdgeTracingClass)
    {
        imageEdgeTracingClass->setWindowTitle(QApplication::translate("imageEdgeTracingClass", "imageEdgeTracing", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class imageEdgeTracingClass: public Ui_imageEdgeTracingClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMAGEEDGETRACING_H
