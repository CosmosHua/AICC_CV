#include <tool.h>
#include <iosfwd>
#include <iostream>
#include <qDebug>
#include <QQueue>
Tool::Tool()
{

}

QImage Tool::toGray(QImage image)
{

	int width = image.width();
	int height = image.height();
	int **img;
	img = new int*[height];
	for (int i = 0; i < width; i++)
	{
		img[i] = new int[width];
	}
	for (int i = 0; i < height; i++)
	{
		QPoint tempPoint;
		QColor tempColor;
		for (int j = 0; j < width; j++)
		{
			tempPoint = QPoint(j, i);
			tempColor = image.pixelColor(tempPoint);
			img[i][j] = (tempColor.blue() * 11 + tempColor.red() * 30 + tempColor.green() * 59 + 50) / 100;
		}
	}

	QImage rImg = QImage(width, height, QImage::Format_Indexed8);
	rImg.setColorCount(256);
	for (int i = 0; i < 256; i++)
	{
		rImg.setColor(i, qRgb(i, i, i));
	}
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			rImg.setPixel(j, i, img[i][j]);
		}
	}
	return rImg;
}

QImage Tool::toGray(QImage image, double blueEnlarge)
{
	int width = image.width();
	int height = image.height();
	int **img;
	img = new int*[height];
	for (int i = 0; i < width; i++)
	{
		img[i] = new int[width];
	}
	for (int i = 0; i < height; i++)
	{
		QPoint tempPoint;
		QColor tempColor;
		for (int j = 0; j < width; j++)
		{
			tempPoint = QPoint(j, i);
			tempColor = image.pixelColor(tempPoint);
			img[i][j] = (int)tempColor.blue() * 4 * blueEnlarge;
		}
	}

	QImage rImg = QImage(width, height, QImage::Format_Indexed8);
	rImg.setColorCount(1024);
	for (int i = 0; i < 1024; i++)
	{
		rImg.setColor(i, qRgb(i, i, i));
	}
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			rImg.setPixel(j, i, img[i][j]);
		}
	}
	return rImg;
}

QImage Tool::segmentation(QImage image, int thresholdValue)
{
	int width = image.width();
	int height = image.height();
	int **img;
	img = new int*[height];
	for (int i = 0; i < width; i++)
	{
		img[i] = new int[width];
	}
	for (int i = 0; i < height; i++)
	{
		QPoint tempPoint;
		QColor tempColor;
		for (int j = 0; j < width; j++)
		{
			tempPoint = QPoint(j, i);
			tempColor = image.pixelColor(tempPoint);
			img[i][j] = (tempColor.blue() * 11 + tempColor.red() * 30 + tempColor.green() * 59 + 50) / 100;
			if (img[i][j] > thresholdValue)
			{
				img[i][j] = 255;
			}
			else
			{
				img[i][j] = 0;
			}
		}
	}

	QImage rImg = QImage(width, height, QImage::Format_Indexed8);
	rImg.setColorCount(256);
	for (int i = 0; i < 256; i++)
	{
		rImg.setColor(i, qRgb(i, i, i));
	}
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			rImg.setPixel(j, i, img[i][j]);
		}
	}
	return rImg;
}

QImage Tool::segmentation(QImage image, int thresholdValue1, int thresholdValue2)
{
	int width = image.width();
	int height = image.height();
	int **img;
	img = new int*[height];
	for (int i = 0; i < width; i++)
	{
		img[i] = new int[width];
	}
	for (int i = 0; i < height; i++)
	{
		QPoint tempPoint;
		QColor tempColor;
		for (int j = 0; j < width; j++)
		{
			tempPoint = QPoint(j, i);
			tempColor = image.pixelColor(tempPoint);
			img[i][j] = (tempColor.blue() * 11 + tempColor.red() * 30 + tempColor.green() * 59 + 50) / 100;
			if (img[i][j] > thresholdValue1&&img[i][j] < thresholdValue2)
			{
				img[i][j] = 0;
			}
			else
			{
				img[i][j] = 255;
			}
		}
	}
	QImage rImg = QImage(width, height, QImage::Format_Indexed8);
	rImg.setColorCount(256);
	for (int i = 0; i < 256; i++)
	{
		rImg.setColor(i, qRgb(i, i, i));
	}
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			rImg.setPixel(j, i, img[i][j]);
		}
	}
	return rImg;

}

QImage Tool::toImageSeg(int **imgArray, int iStart, int jStart, int size)
{
	int width = size;
	int height = size;
	int **img;
	img = new int*[size];
	for (int i = 0; i < size; i++)
	{
		img[i] = new int[size];
	}
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			img[i][j] = imgArray[iStart + i][jStart + j];
		}
	}
	return toImage(img, size, size);
}

void Tool::ImageSeg(int ** imgArray, int ** imgMidArray, int iStart, int jStart, int size)
{
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			imgMidArray[i][j] = imgArray[iStart + i][jStart + j];
		}
	}
}

QImage Tool::toImage(uchar ** imgDivid, int width, int height)
{
	QImage rImg = QImage(width, height, QImage::Format_Indexed8);
	rImg.setColorCount(256);
	for (int i = 0; i < 256; i++)
	{
		rImg.setColor(i, qRgb(i, i, i));
	}
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			rImg.setPixel(j, i, (int)imgDivid[i][j]);
		}
	}
	return rImg;
}

QImage Tool::toImage(int ** imgDivid, int width, int height)
{
	QImage rImg = QImage(width, height, QImage::Format_Indexed8);
	rImg.setColorCount(256);
	for (int i = 0; i < 256; i++)
	{
		rImg.setColor(i, qRgb(i, i, i));
	}
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			rImg.setPixel(j, i, imgDivid[i][j]);
		}
	}
	return rImg;
}

int Tool::getThresholdValue(int ** imgDivid, int width, int height)
{
	int thresholdValue = 0;
	int *count;//�洢256����ɫ�ĸ���
	count = new int[257];
	int *countMid;//�м�����
	countMid = new int[257];
	for (int i = 0; i < 257; i++)//ͳ��ÿһ�е�����
	{
		count[i] = 0;
	}
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			count[imgDivid[i][j]]++;
		}
	}
	for (int i = 0; i < 257; i++)
	{
		countMid[i] = count[i];
	}
	//��count��������
	int posibleMax = 0;
	for (int i = 0; i < 256; i++)
	{
		posibleMax = countMid[i];
		for (int j = i + 1; j < 256; j++)
		{
			if (countMid[j] > posibleMax)
			{
				posibleMax = countMid[j];
				int t = countMid[j];
				countMid[j] = countMid[i];
				countMid[i] = t;
			}
		}
	}
	for (int i = 0; i < 257; i++)//ͳ��ÿһ�е�����
	{
		if (count[i] == countMid[1])
		{
			thresholdValue = i;
		}
	}
	return thresholdValue + 5;
}

int Tool::getThresholdValueWithVarimax(int ** imgDivid, int width, int height)
{
	double w0 = 0, w1 = 0;//��ֵ���ߵĸ���
	double u0 = 0, u1 = 0;//��ֵ���ߵĻҶ�ƽ��ֵ
	double u = 0;//����ͼ��ĻҶ�ƽ��ֵ
	double variance = 0;//����
	int thresholdValue = 0;//��ֵ
	int *count;//�洢256����ɫ�ĸ���
	count = new int[256];
	int *countMid;//�м�����
	countMid = new int[256];
	for (int i = 0; i < 256; i++)//ͳ��ÿһ�е�����
	{
		count[i] = 0;
	}
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			count[imgDivid[i][j]]++;
		}
	}
	double * probability;//�������
	probability = new double[256];
	for (int i = 0; i < 256; i++)//ͳ��ÿһ�е�����
	{
		probability[i] = (double)count[i] / (width*height);
	}
	//���Ƿ���������ֵ
	int T;//������ʱ��ֵ
	for (int i = 10; i < 240; i++)
	{
		T = i;
		for (int j = 0; j < T; j++)
		{
			if (probability[j] > 0.0000000000000000001)
			{
				w0 += probability[j];
			}
		}
		w1 = 1 - w0;
		for (int j = 0; j < T; j++)
		{
			if (((probability[j] * j) / w0) > 0.0000000000000000001)
			{
				u0 += (probability[j] * j) / w0;
			}
		}
		for (int j = T; j < 256; j++)
		{
			if (((probability[j] * j) / w1) > 0.0000000000000000001)
			{
				u1 += (probability[j] * j) / w1;
			}
		}
		u = w0*u0 + w1*u1;
		double tempvariance;
		tempvariance = w0*(u0 - u)*(u0 - u) + w1*(u1 - u)*(u1 - u);
		if (tempvariance > variance)
		{
			variance = tempvariance;
			thresholdValue = T;
		}
	}
	return thresholdValue;
}

int Tool::getThresholdValueWithIteration(int ** imgDivid, int width, int height)
{
	double w0 = 0, w1 = 0;//��ֵ���ߵĸ���
	double u0 = 0, u1 = 0;//��ֵ���ߵĻҶ�ƽ��ֵ
	double u = 0;//����ͼ��ĻҶ�ƽ��ֵ
	double variance = 0;//����
	int thresholdValue = 128;//��ֵ
	int *count;//�洢256����ɫ�ĸ���
	count = new int[256];
	int *countMid;//�м�����
	countMid = new int[256];
	for (int i = 0; i < 256; i++)//ͳ��ÿһ�е�����
	{
		count[i] = 0;
	}
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			count[imgDivid[i][j]]++;
		}
	}
	double * probability;//�������
	probability = new double[256];
	for (int i = 0; i < 256; i++)//ͳ��ÿһ�е�����
	{
		probability[i] = (double)count[i] / (width*height);
	}
	//����������ֵ
	int T;//������ʱ��ֵ
	for (int i = 10; i < 240; i++)
	{
		T = i;
		for (int j = 0; j < T; j++)
		{
			if (probability[j] > 0.0000000000000000001)
			{
				w0 += probability[j];
			}
		}
		w1 = 1 - w0;
		for (int j = 0; j < T; j++)
		{
			if (((probability[j] * j) / w0) > 0.0000000000000000001)
			{
				u0 += (probability[j] * j) / w0;
			}
		}
		for (int j = T; j < 256; j++)
		{
			if (((probability[j] * j) / w1) > 0.0000000000000000001)
			{
				u1 += (probability[j] * j) / w1;
			}
		}
		u = w0*u0 + w1*u1;
		if ((u0 + u1) / 2 - thresholdValue < 0.0000001)
		{
			return thresholdValue;
		}
		thresholdValue = (int)(u0 + u1) / 2;
	}
	return thresholdValue;
}

int Tool::getThresholdValueWithOtsu(int ** imgDivid, int width, int height)
{
	int T = 0; //Otsu�㷨��ֵ  
	double varValue = 0; //��䷽���м�ֵ����  
	double w0 = 0; //ǰ�����ص�����ռ����  
	double w1 = 0; //�������ص�����ռ����  
	double u0 = 0; //ǰ��ƽ���Ҷ�  
	double u1 = 0; //����ƽ���Ҷ�  
	double totalNum = width*height;
	int *Histogram;//�洢256����ɫ�ĸ���
	Histogram = new int[256];
	for (int i = 0; i < 256; i++)//ͳ��ÿһ�е�����
	{
		Histogram[i] = 0;
	}
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			Histogram[imgDivid[i][j]]++;
		}
	}
	for (int i = 0; i < 255; i++)
	{
		//ÿ�α���֮ǰ��ʼ��������  
		w1 = 0;       u1 = 0;       w0 = 0;       u0 = 0;
		//***********����������ֵ����**************************  
		for (int j = 0; j <= i; j++) //�������ָ�ֵ����  
		{
			if (Histogram[j] > 0.0000000000000000001)
			{
				w1 += Histogram[j];  //�����������ص�����  
				u1 += j*Histogram[j]; //�������������ܻҶȺ�  
			}
		}
		//if (w1 == 0) //�����������ص���Ϊ0ʱ�˳�  
		//{
		//	break;
		//}
		u1 = u1 / w1; //��������ƽ���Ҷ�  
		w1 = w1 / totalNum; // �����������ص�����ռ����  
							//***********����������ֵ����**************************  

							//***********ǰ��������ֵ����**************************  
		for (int k = i + 1; k < 255; k++)
		{
			if (Histogram[k] > 0.0000000000000000001)
			{
				w0 += Histogram[k];  //ǰ���������ص�����  
				u0 += k*Histogram[k]; //ǰ�����������ܻҶȺ� 
			}
		}
		//if (w0 == 0) //ǰ���������ص���Ϊ0ʱ�˳�  
		//{
		//	break;
		//}
		u0 = u0 / w0; //ǰ������ƽ���Ҷ�  
		w0 = w0 / totalNum; // ǰ���������ص�����ռ����  
							//***********ǰ��������ֵ����**************************  

							//***********��䷽�����******************************  
		double varValueI = w0*w1*(u1 - u0)*(u1 - u0); //��ǰ��䷽�����  
		if (varValue < varValueI)
		{
			varValue = varValueI;
			T = i;
		}
	}
	return T;
}

int Tool::getThresholdValueWithOtsuParty(int ** imgDivid, int width, int height)
{
	int T = 0; //Otsu�㷨��ֵ  
	double varValue = 0; //��䷽���м�ֵ����  
	double w0 = 0; //ǰ�����ص�����ռ����  
	double w1 = 0; //�������ص�����ռ����  
	double u0 = 0; //ǰ��ƽ���Ҷ�  
	double u1 = 0; //����ƽ���Ҷ�  
	double totalNum = width*height;
	int *Histogram;//�洢256����ɫ�ĸ���
	Histogram = new int[256];
	for (int i = 0; i < 256; i++)//ͳ��ÿһ�е�����
	{
		Histogram[i] = 0;
	}

	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			if (imgDivid[i][j] != 255)
			{
				Histogram[imgDivid[i][j]]++;
			}
		}
	}

	for (int i = 0; i < 255; i++)
	{
		//ÿ�α���֮ǰ��ʼ��������  
		w1 = 0;       u1 = 0;       w0 = 0;       u0 = 0;
		//***********����������ֵ����**************************  
		for (int j = 0; j <= i; j++) //�������ָ�ֵ����  
		{
			if (Histogram[j] > 0.0000000000000000001)
			{
				w1 += Histogram[j];  //�����������ص�����  
				u1 += j*Histogram[j]; //�������������ܻҶȺ�  
			}
		}
		//if (w1 == 0) //�����������ص���Ϊ0ʱ�˳�  
		//{
		//	break;
		//}
		u1 = u1 / w1; //��������ƽ���Ҷ�  
		w1 = w1 / totalNum; // �����������ص�����ռ����  
							//***********����������ֵ����**************************  

							//***********ǰ��������ֵ����**************************  
		for (int k = i + 1; k < 255; k++)
		{
			if (Histogram[k] > 0.0000000000000000001)
			{
				w0 += Histogram[k];  //ǰ���������ص�����  
				u0 += k*Histogram[k]; //ǰ�����������ܻҶȺ� 
			}
		}
		//if (w0 == 0) //ǰ���������ص���Ϊ0ʱ�˳�  
		//{
		//	break;
		//}
		u0 = u0 / w0; //ǰ������ƽ���Ҷ�  
		w0 = w0 / totalNum; // ǰ���������ص�����ռ����  
							//***********ǰ��������ֵ����**************************  

							//***********��䷽�����******************************  
		double varValueI = w0*w1*(u1 - u0)*(u1 - u0); //��ǰ��䷽�����  
		if (varValue < varValueI)
		{
			varValue = varValueI;
			T = i;
		}
	}
	return T;
}

int Tool::getThresholdValueWithFrequency(int ** imgDivid, int width, int height, double frequency)
{
	int T = 0; //Otsu�㷨��ֵ
	int TSum=0;//��ֵT��ǰ�����ص�����
	int sum=width*height;//���ص�����
	int *Histogram;//�洢256����ɫ�ĸ���
	Histogram = new int[256];
	for (int i = 0; i < 256; i++)//ͳ��ÿһ�е�����
	{
		Histogram[i] = 0;
	}

	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			if (imgDivid[i][j] != 255)
			{
				Histogram[imgDivid[i][j]]++;
				//sum++;
			}
		}
	}

	while ((double)TSum/sum<frequency)
	{
		TSum += Histogram[T++];
	}

	return T;
}

int Tool::getThresholdValue(int ** imgDivid, int width, int height, int highValue, int lowValue)
{
	int sum = 0;
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			sum += imgDivid[i][j];
		}
	}

	if (sum / (width*height) > 125)
	{
		return highValue;
	}
	else
	{
		return lowValue;
	}
}

int Tool::getRadius(int ** imgDivid, int width, int height, int x, int y)
{
	int y_left = 0, y_right = 0, x_top = 0, x_bottom = 0, acrossLength = 0, standLength = 0;
	for (int i = y; i >= 0; i--)
	{
		if (imgDivid[x][i] == 0)
		{
			y_left++;
		}
		else
		{
			break;
		}
	}
	for (int i = y; i < width; i++)
	{
		if (imgDivid[x][i] == 0)
		{
			y_right++;
		}
		else
		{
			break;
		}
	}
	for (int i = x; i >= 0; i--)
	{
		if (imgDivid[i][y] == 0)
		{
			x_top++;
		}
		else
		{
			break;
		}
	}
	for (int i = x; i < height; i++)
	{
		if (imgDivid[i][y] == 0)
		{
			x_bottom++;
		}
		else
		{
			break;
		}
	}
	acrossLength = y_left + y_right + 1;
	standLength = x_top + x_bottom + 1;
	if (acrossLength > standLength)
	{
		return standLength;
	}
	else
	{
		return acrossLength;
	}
}

int Tool::getRadiusMax(int ** imgDivid, int width, int height, int x, int y)
{
	int y_left = 0, y_right = 0, x_top = 0, x_bottom = 0, acrossLength = 0, standLength = 0;
	for (int i = y; i >= 0; i--)
	{
		if (imgDivid[x][i] == 0)
		{
			y_left++;
		}
		else
		{
			break;
		}
	}
	for (int i = y; i < width; i++)
	{
		if (imgDivid[x][i] == 0)
		{
			y_right++;
		}
		else
		{
			break;
		}
	}
	for (int i = x; i >= 0; i--)
	{
		if (imgDivid[i][y] == 0)
		{
			x_top++;
		}
		else
		{
			break;
		}
	}
	for (int i = x; i < height; i++)
	{
		if (imgDivid[i][y] == 0)
		{
			x_bottom++;
		}
		else
		{
			break;
		}
	}
	acrossLength = y_left + y_right + 1;
	standLength = x_top + x_bottom + 1;
	if (acrossLength < standLength)
	{
		return standLength;
	}
	else
	{
		return acrossLength;
	}
}

void Tool::expandImg(int ** imgDivid, int width, int height)
{
	for (int i = 1; i < height-1; i++)
	{
		for (int j = 1; j < width-1; j++)
		{
			if (imgDivid[i][j] == 255)
			{
				if (imgDivid[i + 1][j] == 0 || imgDivid[i + 1][j + 1] == 0 || imgDivid[i + 1][j - 1] == 0 || imgDivid[i][j + 1] == 0 ||
					imgDivid[i][j - 1] == 0 || imgDivid[i - 1][j] == 0 || imgDivid[i - 1][j + 1] == 0 || imgDivid[i - 1][j - 1] == 0)
				{
					imgDivid[i][j] = 125;
				}
			}
			
		}
	}
	for (int i = 1; i < height - 1; i++)
	{
		for (int j = 1; j < width - 1; j++)
		{
			if (imgDivid[i][j] == 125)
			{			
					imgDivid[i][j] = 0;
			}

		}
	}
}

int Tool::getMaxExcept255(int ** imgArray, int width, int height)
{
	int max = 0;
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			if (max < imgArray[i][j] && imgArray[i][j] != 255)
			{
				max = imgArray[i][j];
			}
		}
	}
	return max;
}

void Tool::moveNoise(int ** srcimgArray, int width, int height, int detectSize)
{
	int **detectImgArray;//����ָ��ÿһ��С��ͼ��
	detectImgArray = new int*[detectSize];
	for (int i = 0; i < detectSize; i++)
	{
		detectImgArray[i] = new int[detectSize];
	}
	//�ֱ��ÿһ��С����������Ⲣȥ��
	for (int i = 0; i < 250 / detectSize; i++)
	{
		for (int j = 0; j < 250 / detectSize; j++)
		{
			ImageSeg(srcimgArray, detectImgArray, i * detectSize, j * detectSize, detectSize);//�ָ�ͼ��
																									  //���ϱ߽�Ϊ��ʼ�㿪ʼ���,����Ϊһ����������ɫ����Ϊ125
			for (int k = 0; k < detectSize; k++)
			{
				if (detectImgArray[0][k] == 0)//���ܵ���ʼ��
				{
					QQueue<QPoint> pointQueue;
					pointQueue.enqueue(QPoint(0, k));
					while (!(pointQueue.isEmpty()))
					{
						QPoint currentPoint = pointQueue.dequeue();
						int x = currentPoint.x();
						int y = currentPoint.y();
						detectImgArray[x][y] = 125;
						//��ÿ����������е����
						if (x == 0 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}

						}
						else if (x == 0 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (x == detectSize - 1 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
						}
						else if (x == detectSize - 1 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}

							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == detectSize - 1)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}

						}
						else if (y == detectSize - 1)
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
						}
						else
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
						}
					}
				}
			}

			for (int k = 0; k < detectSize; k++)
			{
				if (detectImgArray[k][detectSize - 1] == 0)//���ܵ���ʼ��
				{
					QQueue<QPoint> pointQueue;
					pointQueue.enqueue(QPoint(k, detectSize - 1));
					while (!(pointQueue.isEmpty()))
					{
						QPoint currentPoint = pointQueue.dequeue();
						int x = currentPoint.x();
						int y = currentPoint.y();
						detectImgArray[x][y] = 125;
						//��ÿ����������е����
						if (x == 0 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}

						}
						else if (x == 0 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (x == detectSize - 1 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
						}
						else if (x == detectSize - 1 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}

							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == detectSize - 1)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}

						}
						else if (y == detectSize - 1)
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
						}
						else
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
						}
					}
				}
			}

			for (int k = 0; k < detectSize; k++)
			{
				if (detectImgArray[detectSize - 1][k] == 0)//���ܵ���ʼ��
				{
					QQueue<QPoint> pointQueue;
					pointQueue.enqueue(QPoint(detectSize - 1, k));
					while (!(pointQueue.isEmpty()))
					{
						QPoint currentPoint = pointQueue.dequeue();
						int x = currentPoint.x();
						int y = currentPoint.y();
						detectImgArray[x][y] = 125;
						//��ÿ����������е����
						if (x == 0 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}

						}
						else if (x == 0 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (x == detectSize - 1 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
						}
						else if (x == detectSize - 1 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}

							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == detectSize - 1)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}

						}
						else if (y == detectSize - 1)
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
						}
						else
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
						}
					}
				}
			}
			for (int k = 0; k < detectSize; k++)
			{
				if (detectImgArray[k][0] == 0)//���ܵ���ʼ��
				{
					QQueue<QPoint> pointQueue;
					pointQueue.enqueue(QPoint(k, 0));
					while (!(pointQueue.isEmpty()))
					{
						QPoint currentPoint = pointQueue.dequeue();
						int x = currentPoint.x();
						int y = currentPoint.y();
						detectImgArray[x][y] = 125;
						//��ÿ����������е����
						if (x == 0 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}

						}
						else if (x == 0 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (x == detectSize - 1 && y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
						}
						else if (x == detectSize - 1 && y == detectSize - 1)
						{
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
						}
						else if (y == 0)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}

							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
						}
						else if (x == detectSize - 1)
						{
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}

						}
						else if (y == detectSize - 1)
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
						}
						else
						{
							if (detectImgArray[x - 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y));
								detectImgArray[x - 1][y] = 125;
							}
							if (detectImgArray[x + 1][y] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y));
								detectImgArray[x + 1][y] = 125;
							}
							if (detectImgArray[x][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y - 1));
								detectImgArray[x][y - 1] = 125;
							}
							if (detectImgArray[x + 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y - 1));
								detectImgArray[x + 1][y - 1] = 125;
							}

							if (detectImgArray[x - 1][y - 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y - 1));
								detectImgArray[x - 1][y - 1] = 125;
							}
							if (detectImgArray[x - 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x - 1, y + 1));
								detectImgArray[x - 1][y + 1] = 125;
							}
							if (detectImgArray[x][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x, y + 1));
								detectImgArray[x][y + 1] = 125;
							}
							if (detectImgArray[x + 1][y + 1] == 0)
							{
								pointQueue.enqueue(QPoint(x + 1, y + 1));
								detectImgArray[x + 1][y + 1] = 125;
							}
						}
					}
				}
			}

			for (int m = i * detectSize; m < detectSize + i * detectSize; m++)
			{
				for (int n = j * detectSize; n < detectSize + j * detectSize; n++)
				{
					if (detectImgArray[m - i * detectSize][n - j * detectSize] == 125)
					{
						srcimgArray[m][n] = 0;
					}
					else
					{
						srcimgArray[m][n] = 255;
					}
				}
			}

		}
	}
}
