#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_imageEdgeTracing.h"

class imageEdgeTracing : public QMainWindow
{
	Q_OBJECT

public:
	imageEdgeTracing(QWidget *parent = Q_NULLPTR);
	QImage toGray(QImage image);

private:
	Ui::imageEdgeTracingClass ui;
};

